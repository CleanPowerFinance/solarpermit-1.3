import datetime
from django.db import models
from django import forms
from django.forms import ModelForm
from django.contrib.auth.models import User
from django.conf import settings
from website.models import Region, Jurisdiction, OrganizationMember, Organization#, JurisdictionContributor
import json
from django.core import serializers
from website.utils.mathUtil import MathUtil
from website.utils.datetimeUtil import DatetimeHelper
#from django.db.models import Count, Sum
import datetime

class Template(models.Model):
    TEMPLATE_TYPE_CHOICES = (
        ('CT', 'Callouts Template'), #there's only one callouts template in the system, for all jurisdictions
        ('RT', 'Requirements Template'),
        ('IT', 'Information Template'), #for jurisdiction's general info
        ('AT', 'Application Template'),
        #('JR', 'Jurisdiction Requirements'), #jurisdiction no longer has requirement templates
        ('JA', 'Jurisdiction Application'),
        ('CF', 'Jurisdiction Custom Field'),        
    )
    name = models.CharField(max_length=128, blank=True, null=True, db_index=True)
    description = models.TextField(blank=True, null=True)
    template_type = models.CharField(choices=TEMPLATE_TYPE_CHOICES, max_length=8, blank=True, null=False, db_index=True, default="")
    jurisdiction = models.ForeignKey(Jurisdiction, blank=True, null=True, db_index=True)
    reviewed = models.BooleanField(default=False, db_index=True)
    accepted = models.BooleanField(default=False, db_index=True)
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    modify_datetime = models.DateTimeField(blank=True, null=True)
    def __unicode__(self):
        return self.name
    class Meta:
        app_label = 'website'
        
    def get_jurisdiction_question_templates(self, jurisdiction):
        templates = Template.objects.filter(template_type__exact='RT')
        custom_templates = Template.objects.filter(template_type__exact='CF', jurisdiction = jurisdiction)
        
        jurisdiction_templates = []
        for template in templates:
            jurisdiction_templates.append(template.id)
            
        for template in custom_templates:
            jurisdiction_templates.append(template.id)   
            
        return jurisdiction_templates          

FORM_TYPE_CHOICES = (
    ('N', 'Number'),
    ('D', 'Date'),
    ('TI', 'Time'),
    ('C', 'Currency'),
    ('TE', 'Text'),
    ('TA', 'Text Area'),
    ('R', 'Radio Button'),
    ('DD', 'Dropdown'),
    ('AC', 'Auto Complete'),
    ('F', 'File Upload'),
    ('CF', 'Custom Field'),
    ('MF', 'Multiple Field'),    
)

class AnswerChoiceGroup(models.Model):
    name = models.CharField(max_length=128, blank=True, null=True, db_index=True)
    description = models.TextField(blank=True, null=True)
    def __unicode__(self):
        return self.name
    class Meta:
        app_label = 'website'

class AnswerChoice(models.Model):
    answer_choice_group = models.ForeignKey(AnswerChoiceGroup, db_index=True)
    label = models.CharField(max_length=255, blank=True, null=True)
    value = models.CharField(max_length=255, blank=True, null=True)
    display_order = models.PositiveSmallIntegerField(blank=True, null=True)
    class Meta:
        app_label = 'website'

class QuestionCategory(models.Model):
    name = models.CharField(max_length=128, blank=True, null=True, db_index=True)
    description = models.TextField(blank=True, null=True)
    reviewed = models.BooleanField(default=False)
    accepted = models.BooleanField(default=False)
    display_order = models.PositiveSmallIntegerField(blank=True, null=True)
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    modify_datetime = models.DateTimeField(blank=True, null=True)
    def __unicode__(self):
        return self.name
    
    def questionsNumber(self):
        questions = Question.objects.filter(category = self)
  
        return len(questions)
    class Meta:
        app_label = 'website'

#certain criteria that determines if an item is applicable or not
class Applicability(models.Model):
    name = models.CharField(max_length=128, blank=True, null=True, db_index=True)
    description = models.TextField(blank=True, null=True)
    reviewed = models.BooleanField(default=False)
    accepted = models.BooleanField(default=False)
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    modify_datetime = models.DateTimeField(blank=True, null=True)
    def __unicode__(self):
        return self.name
    class Meta:
        app_label = 'website'
'''        
class CustomQuestion(models.Model):

    label = models.TextField(blank=True, null=True) #label to display if it is shown in field format
    question = models.TextField(blank=True, null=True) #question to display if it is show as a question
    instruction = models.TextField(blank=True, null=True)
    category = models.ForeignKey(QuestionCategory, blank=True, null=True, db_index=True)
    applicability = models.ForeignKey(Applicability, blank=True, null=True)
    form_type = models.CharField(choices=FORM_TYPE_CHOICES, max_length=8, blank=True, null=True)
    answer_choice_group = models.ForeignKey(AnswerChoiceGroup, blank=True, null=True)
    display_order = models.PositiveSmallIntegerField(blank=True, null=True) #display order within the category
    default_value = models.TextField(blank=True, null=True) #convert all default values to text
    reviewed = models.BooleanField(default=False, db_index=True)
    accepted = models.BooleanField(default=False, db_index=True)
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    modify_datetime = models.DateTimeField(blank=True, null=True)
    template = models.TextField(blank=True, null=True)
    validation_class = models.TextField(blank=True, null=True)
    js = models.TextField(blank=True, null=True)
    field_attributes = models.TextField(blank=True, null=True)
    terminology = models.TextField(blank=True, null=True)
    has_multivalues = models.BooleanField(default=False) 
    qtemplate = models.ForeignKey(Template, null=True, db_index=True)  
    question_type = models.CharField(max_length=16, db_index=True, default='custom')            # this is to help using same templates for both predefined and custom questions
    def __unicode__(self):
        if self.question != None:
            return self.question[:64] + '...'
        else:
            return str(self.id)
    class Meta:
        app_label = 'website'        
'''
      
    
        
class Question(models.Model):
    category = models.ForeignKey(QuestionCategory, blank=True, null=True, db_index=True)
    label = models.TextField(blank=True, null=True) #label to display if it is shown in field format
    question = models.TextField(blank=True, null=True) #question to display if it is show as a question
    instruction = models.TextField(blank=True, null=True)
    category = models.ForeignKey(QuestionCategory, blank=True, null=True, db_index=True)
    applicability = models.ForeignKey(Applicability, blank=True, null=True)
    form_type = models.CharField(choices=FORM_TYPE_CHOICES, max_length=8, blank=True, null=True)
    answer_choice_group = models.ForeignKey(AnswerChoiceGroup, blank=True, null=True)
    display_order = models.PositiveSmallIntegerField(blank=True, null=True) #display order within the category
    default_value = models.TextField(blank=True, null=True) #in JSON format
    reviewed = models.BooleanField(default=False, db_index=True)
    accepted = models.BooleanField(default=False, db_index=True)
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    modify_datetime = models.DateTimeField(blank=True, null=True)
    template = models.TextField(blank=True, null=True)
    validation_class = models.TextField(blank=True, null=True)
    js = models.TextField(blank=True, null=True)
    field_attributes = models.TextField(blank=True, null=True)
    terminology = models.TextField(blank=True, null=True)
    has_multivalues = models.BooleanField(default=False) 
    qtemplate = models.ForeignKey(Template, null=True, db_index=True)  
    display_template = models.TextField(blank=True, null=True)    
    field_suffix = models.CharField(max_length=32, blank=True, null=True)
    migration_type = models.CharField(max_length=64, blank=True, null=True) #type of migration that's needed to convert the answer
    creator = models.ForeignKey(User, blank=True, null=True)
    state_exclusive = models.TextField(blank=True, null=True)
    description = models.TextField(blank=True, null=True)
        
    def __unicode__(self):
        if self.question != None:
            return self.question[:64] + '...'
        else:
            return str(self.id)
    class Meta:
        app_label = 'website'
        
    def migrate_temmplatequestion_to_question(self):
        template_questions = TemplateQuestion.objects.all()
        for template_question in template_questions:

            try:
                question = Question.objects.get(id=template_question.question_id)
             
                question.qtemplate_id = template_question.template_id
              
                question.save()
               
            except:
                print "no question for id = " + str(template_question.question_id)
        
    def get_custom_fields_by_jurisdiction_by_category(self, jurisdiction_obj, category_id):
        questions = [] #if this is none, will cause template loop to crash!!!
        templates = Template.objects.filter(template_type__iexact='CF', jurisdiction=jurisdiction_obj)
        
        if len(templates) > 0:
            #obj = objs[0]
            '''
            question_ids = TemplateQuestion.objects.filter(template=obj).values_list('question_id')
            if len(question_ids) > 0:
                category_obj = QuestionCategory.objects.get(id=category_id)
                questions = Question.objects.filter(id__in=question_ids, category=category_obj)
            '''    
            category_obj = QuestionCategory.objects.get(id=category_id)   
            #questions = Question.objects.filter(id__in=all_template_question_ids, category__exact=category_obj, accepted__exact=1).exclude(form_type__iexact='CF').order_by('display_order')
            questions = Question.objects.filter(qtemplate__in=templates, category__exact=category_obj, accepted__exact=1).order_by('display_order')
                           
           
        return questions
            
    def get_org_question_categories(self):
        wanted_categories = ('Jurisdiction Informations', 'Organization Contact Information')
        template = 'IT'
                
        found_categories = []
        template_objs = Template.objects.filter(template_type__iexact=template)
        categories = self.get_categories_of_questions(template_objs)
        for category in categories:
            if category.name in wanted_categories:
                found_categories.append(category)
                
        return found_categories
          
    
    def get_answer_jurisdiction_numbers(self):
        usage_count = AnswerReference.objects.filter(question__exact=self, is_current__exact=1).values_list('jurisdiction_id').distinct().count()
        math_util_obj = MathUtil()
        if math_util_obj.is_number(usage_count):
            return usage_count
        else:
            return 0
        

                        
    def get_questions_with_no_answers(self, templates, jurisdiction_id, is_callout):
        juris = Jurisdiction.objects.get(id=jurisdiction_id)

        answer_question_ids = AnswerReference.objects.filter(is_callout__exact=is_callout, jurisdiction__exact=juris).values_list('question_id'); 
         
        # all the questions in the template
        all_template_question_ids = TemplateQuestion.objects.filter(template__in=templates).values_list('question_id') 
           
        no_answer_questions = Question.objects.filter(id__in=all_template_question_ids).exclude(id__in=answer_question_ids)   
   
        return no_answer_questions        
        
    def get_questions_with_no_answers_by_category(self, templates, jurisdiction_id, cid, is_callout):
        juris = Jurisdiction.objects.get(id=jurisdiction_id)
        #templates = Template.objects.filter(template_type__iexact=template_type_str, jurisdiction__isnull=True) #look for callout template
        answer_question_ids = AnswerReference.objects.filter(is_callout__exact=is_callout, jurisdiction__exact=juris).exclude(rating_status__iexact="D").values_list('question_id'); 
 
        # all the questions in the template
        all_template_question_ids = TemplateQuestion.objects.filter(template__in=templates).values_list('question_id') 
                 
        #get categories of all the questions that have no answers"
        category_obj = QuestionCategory.objects.get(id=cid)   
        no_answer_questions = Question.objects.filter(id__in=all_template_question_ids, category__exact=category_obj).exclude(id__in=answer_question_ids).order_by('display_order')   
                   
        return no_answer_questions   
        
    def get_categories_of_questions_with_no_answers(self,templates, jurisdiction_id, is_callout):
        juris = Jurisdiction.objects.get(id=jurisdiction_id)
        #templates = Template.objects.filter(template_type__iexact=template_type_str, jurisdiction__isnull=True) #look for callout template
        answer_question_ids = AnswerReference.objects.filter(is_callout__exact=is_callout, jurisdiction__exact=juris).exclude(rating_status__iexact="D").values_list('question_id'); 
        
        # all the questions in the template
        all_template_question_ids = TemplateQuestion.objects.filter(template__in=templates).values_list('question_id')
        
        #get categories of all the questions that have no answers"
        category_ids = Question.objects.filter(id__in=all_template_question_ids).exclude(id__in=answer_question_ids).distinct('category_id').values_list('category_id')
        category = QuestionCategory.objects.filter(id__in=category_ids).order_by('name')      
        
        return category
    
    def get_categories_of_questions(self, templates):
        # all the questions in the template
        all_template_question_ids = TemplateQuestion.objects.filter(template__in=templates).values_list('question_id')
        
        #get categories of all the questions that have no answers"
        category_ids = Question.objects.filter(id__in=all_template_question_ids).distinct('category_id').values_list('category_id')
        category = QuestionCategory.objects.filter(id__in=category_ids).order_by('display_order')      
        
        return category
    
    def get_template_question_categories(self, template_type, jurisdiction_id):
        juris = Jurisdiction.objects.get(id=jurisdiction_id)
        templates = Template.objects.filter(template_type__iexact=template_type)
        # all the questions in the template
        all_template_question_ids = TemplateQuestion.objects.filter(template__in=templates).values_list('question_id')
        
        #get categories of all the questions"
        category_ids = Question.objects.filter(id__in=all_template_question_ids).distinct('category_id').values_list('category_id')
        categories = QuestionCategory.objects.filter(id__in=category_ids).order_by('name')      
        
        return categories    
    '''
    def get_questions_by_category(self, templates, cid):
        all_template_question_ids = TemplateQuestion.objects.filter(template__in=templates).values_list('question_id') 
                
        #get categories of all the questions that have no answers"
        category_obj = QuestionCategory.objects.get(id=cid)   
        questions = Question.objects.filter(id__in=all_template_question_ids, category__exact=category_obj, accepted__exact=1).order_by('display_order')
        
        return questions
    '''
    def get_non_cf_questions_by_category(self, templates, cid):
        #all_template_question_ids = TemplateQuestion.objects.filter(template__in=templates).values_list('question_id') 
                
        category_obj = QuestionCategory.objects.get(id=cid)   
        questions = Question.objects.filter(id__in=all_template_question_ids, category__exact=category_obj, accepted__exact=1).exclude(form_type__iexact='CF').order_by('display_order')
        #questions = Question.objects.filter(qtemplate__in=templates, category__exact=category_obj, accepted__exact=1).order_by('display_order')
        
        return questions
    
    def get_questions_by_category(self, templates, cid):
        #all_template_question_ids = TemplateQuestion.objects.filter(template__in=templates).values_list('question_id') 
                
        category_obj = QuestionCategory.objects.get(id=cid)   
        #questions = Question.objects.filter(id__in=all_template_question_ids, category__exact=category_obj, accepted__exact=1).exclude(form_type__iexact='CF').order_by('display_order')
        questions = Question.objects.filter(qtemplate__in=templates, category__exact=category_obj, accepted__exact=1).order_by('display_order')
        
        return questions         
    
    def get_answer_choices_for_question(self, qid):
        question_obj = Question.objects.get(id=qid)
        try:
            answer_choice_group_obj = AnswerChoiceGroup.objects.get(id=question_obj.answer_choice_group_id)
            answer_choices = AnswerChoice.objects.filter(answer_choice_group__exact=answer_choice_group_obj).order_by('display_order').values_list('id', 'label')                   
            return answer_choices;
        except: #in case it has no answer choice group
            return []    
        
    def get_answer_by_question(self, question,jurisdiction_id):
        
        answers = AnswerReference.objects.filter(question = question, is_current = 1, jurisdiction__id = jurisdiction_id).order_by('-modify_datetime', '-create_datetime')
       
        try:
            answer = answers[0]
            if answer.value == None:
                #if question.default_value != None:
                #    return question.default_value
                return ''

            return answer.value
        except:
            #if question.default_value != None:
            #    return question.default_value
            return ''  
        
    def get_question_dependencies(self):
        dependencies = {}
    
        first_levels = QuestionDependency.objects.filter(question1__exact=self)
       
        if first_levels:
            for dependency1 in first_levels:
                
                question = Question.objects.get(id=dependency1.question2_id)        
                
                dependencies[dependency1.id] = {}  
                dependencies[dependency1.id]['answer_text'] = dependency1.answer_text
                dependencies[dependency1.id]['question'] = question.question
                dependencies[dependency1.id]['dependency_id'] = dependency1.id
                dependencies[dependency1.id]['question2_id'] = dependency1.question2_id 
                question2 = Question.objects.get(id=dependency1.question2_id)
                dependencies[dependency1.id]['next_level_depenencies'] = question2.get_question_dependencies()

        return dependencies
        
    def get_question_answer_field(self, answer=''):
        #return_str = dforms.CharField(label=_('Answer'), required=False, widget=dforms.TextInput(attrs={'size': 40,}))
        #return_str = RequirementCharForm()
        from askbot.skins.loaders import get_template
        from django.template import Context
        type = self.form_type
            
        acs = []
        if self.answer_choice_group != None:
            acs = AnswerChoice.objects.filter(answer_choice_group = self.answer_choice_group)
        data = {}
        data['question'] = self
        data['acs'] = acs
        data['answer'] = answer
        tp = get_template('website/blocks/question_form_field.html')
        c = Context(data)
        body = tp.render(c)
        return body
        
    def get_question_answer_format(self, question, jurisdiction_id, answer_id, show_answer):
        #return_str = dforms.CharField(label=_('Answer'), required=False, widget=dforms.TextInput(attrs={'size': 40,}))
        #return_str = RequirementCharForm()
        from askbot.skins.loaders import get_template
        from django.template import Context
        type = question.form_type
        
        if show_answer == True:
            if answer_id > 0:
                answer = AnswerReference.objects.get(id=answer_id)
            else:
                answer = self.get_answer_by_question(question, jurisdiction_id)
        else:
            answer = ''
            
        acs = []
        if question.answer_choice_group != None:
            acs = AnswerChoice.objects.filter(answer_choice_group = question.answer_choice_group)
        data = {}
        data['question'] = question
        data['acs'] = acs
        data['answer'] = answer
        tp = get_template('website/blocks/question_form_field.html')
        c = Context(data)
        body = tp.render(c)
        return body
        '''
        return_str = '<input type="text" class="answer" qid="'+str(question.id)+'" id="id_answer_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="" data-orig="">'
        if type == 'N':
            return_str = '<input type="text" class="digits answer" qid="'+str(question.id)+'" id="id_answer_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="'+str(answer)+'" data-orig="'+str(answer)+'">'
        if type == 'D':
            return_str = '<input type="text" class="answer dateISO" qid="'+str(question.id)+'" id="id_answer_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="'+str(answer)+'" data-orig="'+str(answer)+'">'    
        if type == 'TI':
            return_str = '<input type="text" class="time answer" qid="'+str(question.id)+'" id="id_answer_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="'+str(answer)+'" data-orig="'+str(answer)+'">'
        if type == 'C':
            return_str = '<input type="text" class="number answer" qid="'+str(question.id)+'" id="id_answer_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="'+str(answer)+'" data-orig="'+str(answer)+'">'
        if type == 'R':
            return_str = '<div id="radio_'+str(question.id)+'" >'
            return_str += '<input type="hidden" id="id_answer_radio_'+str(question.id)+'" data-orig="" data-type="radio">'
            if question.answer_choice_group != None:
                acs = AnswerChoice.objects.filter(answer_choice_group = question.answer_choice_group)
                ii = 0
                for a in acs:
                    if answer == a.value:
                        return_str += '<div><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_'+str(ii)+'_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="'+str(a.value)+'" checked="checked"/>'+str(a.label)+'</label></div>'
                    else:
                        return_str += '<div><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_'+str(ii)+'_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="'+str(a.value)+'" />'+str(a.label)+'</label></div>'
                    ii = ii + 1
            else:
                if answer == 'Yes':
                    return_str = '<div><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_y_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="Yes" checked="checked"/>Yes</label><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_n_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="No" />No</label></div>'
                elif answer == 'No':
                    return_str = '<div><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_y_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="Yes" />Yes</label><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_n_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="No" checked="checked"/>No</label></div>'
                else:    
                    return_str += '<div><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_y_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="Yes" />Yes</label><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_n_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="No" />No</label></div>'            
            return_str += '</div>'      
            #return_str = '<div id="radio_'+str(question.id)+'"><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_y_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="Yes" />Yes</label><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_n_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="No" />No</label></div>'
            #if answer == 'Yes':
            #    return_str = '<div id="radio_'+str(question.id)+'"><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_y_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="Yes" checked="checked"/>Yes</label><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_n_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="No" />No</label></div>'
            #if answer == 'No':
            #    return_str = '<div id="radio_'+str(question.id)+'"><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_y_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="Yes" />Yes</label><label><input type="radio" qid="'+str(question.id)+'" id="id_answer_n_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="No" checked="checked"/>No</label></div>'
        if type == 'TA':
            return_str = '<textarea name="answer_'+str(question.id)+'" class="answer" qid="'+str(question.id)+'" cols="60" rows="4" id="id_answer_'+str(question.id)+'" data-orig="'+str(answer)+'">'+str(answer)+'</textarea>'
        if type == 'DD':
            return_str = '<select id="id_answer_'+str(question.id)+'" class="answer" qid="'+str(question.id)+'" name="answer_'+str(question.id)+'" data-orig="'+str(answer)+'"><option value="">-----</option>'
            if question.answer_choice_group != None:
                acs = AnswerChoice.objects.filter(answer_choice_group = question.answer_choice_group)
                for ac in acs:
                    if ac.value == answer:
                        return_str += '<option value="'+str(ac.value)+'" selected="selected">'+str(ac.label)+'</option>'
                    else:
                        return_str += '<option value="'+str(ac.value)+'">'+str(ac.label)+'</option>'
            return_str += '</select>'
        if type == 'AC':
            if question.answer_choice_group != None:
                return_str = '<input type="text" gid="'+str(question.answer_choice_group.id)+'" class="autocomplate answer" qid="'+str(question.id)+'" autoid="id_answer_'+str(question.id)+'" id="id_answer1_'+str(question.id)+'" name="answer1_'+str(question.id)+'" value="'+str(answer)+'"><input type="hidden" class="answer" qid="'+str(question.id)+'" id="id_answer_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="'+str(answer)+'" data-orig="'+str(answer)+'">'
            else:
                return_str = '<input type="text" gid="0" class="autocomplate answer" qid="'+str(question.id)+'" autoid="id_answer_'+str(question.id)+'" id="id_answer1_'+str(question.id)+'" name="answer1_'+str(question.id)+'" value="'+str(answer)+'"><input type="hidden" class="answer" qid="'+str(question.id)+'" id="id_answer_'+str(question.id)+'" name="answer_'+str(question.id)+'" value="'+str(answer)+'" data-orig="'+str(answer)+'">'
        if type == 'F':
            answers = AnswerReference.objects.filter(question = question, is_current = 1, jurisdiction__id = jurisdiction_id).order_by('-modify_datetime', '-create_datetime')
            try:
                store_file_name = str(answers[0].file_upload).split('/')[1]
            except:
                store_file_name = '' 
            return_str = '<div id="file-uploader'+str(question.id)+'"></div><input type="hidden" class="answer" qid="'+str(question.id)+'" id="id_answer'+str(question.id)+'" name="answer_'+str(question.id)+'" value="'+str(answer)+'" data-orig="'+str(answer)+'"><label style="float:left;">Comment: </label><textarea name="answercomment_'+str(question.id)+'">'+str(answer)+'</textarea> <input id="filename'+str(question.id)+'" name="filename'+str(question.id)+'" type="hidden" value="'+str(answer)+'"/> <input id="file_store_name'+str(question.id)+'" name="file_store_name'+str(question.id)+'" type="hidden" value="'+store_file_name+'"/>'
            
            script = ' <script type="text/javascript">'
            script += '$(document).ready(function(){'
            script += 'var uploader'+str(question.id)+' = new qq.FileUploader({'
            script += 'element: document.getElementById("file-uploader'+str(question.id)+'"),'
            script += 'action: "/jurisdiction/requirement/uploadfile/",'
            script += 'multiple: false,'
            script += 'onComplete: function(id, fileName, response) {'
            script += 'if (response.error){ $("#filename'+str(question.id)+'").val('');return;} else{$("#filename'+str(question.id)+'").val(fileName);$("#id_answer'+str(question.id)+'").val(fileName).trigger("change");if($("#error_message").is(":visible")) $("#error_message").hide();$("#file_store_name'+str(question.id)+'").val(response.store_name)}'
            script += '}'
            script += '});'
            script += '});'
            script += '</script>'
            
            
                $(document).ready(function(){
                    var uploader = new qq.FileUploader({
                     element: document.getElementById("file-uploader"),
                     action: "/jurisdiction/requirement/uploadfile/",
                     
                     multiple: false,
                     
                     onComplete: function(id, fileName, response) { 
                             if (response.error){
                                 $("#filename").val('');
                                 return ;
                             }else{
                                 $("#filename").val(fileName);if($("#error_message").is(':visible')) $("#error_message").hide();$("#file_store_name").val(response.store_name) 
                             }
                     }
                 });
                });
            </script>
            
            return_str += script
            #return_str = return_str 
        return return_str
        
    def get_question_table(self, question, templates, jurisdiction_id):
        table = '<table style="width:100%;"><tbody>'
        table += '<tr><td colspan="2">'+str(question.question)+'<input type="hidden" name="question" value="'+str(question.id)+'"></td></tr>'
        #table += '<tr></tr>'
        
        #table += '<tr></tr>' style="display:none;" style="display:block;"
        answer =  self.get_answer_by_question(question, jurisdiction_id)
        if answer == '' or answer == None:
            table += '<tr><td style="width:10px;"><label> '+'<input type="checkbox" qid="'+str(question.id)+'" class="include" id="include_'+str(question.id)+'" name="include_'+str(question.id)+'" value="Y"> </label>'+'</td>'
        else:
            table += '<tr><td style="width:10px;"><label> '+'<input type="checkbox" qid="'+str(question.id)+'" class="include" id="include_'+str(question.id)+'" name="include_'+str(question.id)+'" value="Y" checked="checked"> </label>'+'</td>'
        #table += '<tr><td>'+'<input type="checkbox" id="'+str(question.id)+'">'+'</td></tr>'
        if answer == '' or answer == None:
            table += '<td id="tr_'+str(question.id)+'"><label style="float:left;">*</label>'+self.get_question_answer_format(question, jurisdiction_id)
        else:
            return '' #For #180
            table += '<td id="tr_'+str(question.id)+'"><label style="float:left;">*</label>'+self.get_question_answer_format(question, jurisdiction_id)
        table += '<input type="hidden" id="id_hidden_answer_'+str(question.id)+'" value="'+answer+'">'
        table +='</td></tr>'
        #print answer
        table += '</table></tbody>'
        return table  
    '''          

        
#questions in a template, questions are reusable for multiple templates
class TemplateQuestion(models.Model):
    template = models.ForeignKey(Template, db_index=True)
    question = models.ForeignKey(Question, db_index=True)
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    def __unicode__(self):
        return self.template.name + ' - ' + str(self.question.id)
    class Meta:
        app_label = 'website'

RATING_STATUS_CHOICES = (
    ('U', 'Unconfirmed'),
    ('C', 'Confirmed'),
    ('D', 'Disputed'),
)

APPROVAL_STATUS_CHOICES = (
    ('P', 'Pending'),
    ('F', 'Flagged'),
    ('A', 'Approved'),
    ('R', 'Rejected'),
    ('C', 'Cancelled'),    
)

#a question (with or without certain answer) can lead to another question

class QuestionDependency(models.Model):
    question1 = models.ForeignKey(Question, db_index=True, related_name = '_questionDependency_question1')
    answer_text = models.TextField(blank=True, null=True) #if not a choice, text to match
    question2 = models.ForeignKey(Question, db_index=True, related_name = '_questionDependency_question2')
    required = models.BooleanField(default=False) #if this is required
    strength = models.PositiveSmallIntegerField(blank=True, null=True) #how strongly question 2 is needed, 1-10, 10=strongest
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    modify_datetime = models.DateTimeField(blank=True, null=True)
    class Meta:
        app_label = 'website'
    
#answers for a reference template, like the template for electrical requirements in San Jose
class AnswerReference(models.Model):
    jurisdiction = models.ForeignKey(Jurisdiction, blank=True, null=True, db_index=True)
    is_callout = models.BooleanField(default=False) #this is for the callouts section
    question = models.ForeignKey(Question, db_index=True)
    value = models.TextField(blank=True, null=True) #convert all values to text
    file_upload = models.FileField(upload_to='answer_ref_files', blank=True, null=True)
    is_current = models.BooleanField(default=True, db_index=True) #should be the highest rating, or most recent if equal ratings
    rating = models.IntegerField(blank=True, null=True, db_index=True) #rating of this answer
    rating_status = models.CharField(choices=RATING_STATUS_CHOICES, max_length=8, blank=True, null=False, db_index=True, default="U")
    approval_status = models.CharField(choices=APPROVAL_STATUS_CHOICES, max_length=8, blank=True, null=False, db_index=True, default="P")
    creator = models.ForeignKey(User, blank=True, null=True)
    organization = models.ForeignKey(Organization, blank=True, null=True) #org that the creator belongs to at the time
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    modify_datetime = models.DateTimeField(blank=True, null=True)
    status_datetime = models.DateTimeField(blank=True, null=True)    
    migrated_answer_id = models.IntegerField(blank=True, null=True) # to indicate source #not really used, see MigrationHistory!
    #question_type = models.CharField(max_length=16, db_index=True, default='predefined')
    def __unicode__(self):
        return self.value
    class Meta:
        app_label = 'website'
          
        
    def get_answers_by_template_and_categories(self, jurisdiction_id, templates, categories, is_current, is_callout):
        juris = Jurisdiction.objects.get(id=jurisdiction_id)
        #templates = Template.objects.filter(template_type__iexact=template_type)
    
        if len(categories) > 0:
            category_objs = QuestionCategory.objects.filter(name__in=categories)
            questions_by_categories = Question.objects.filter(category__in=category_objs)
            question_ids = TemplateQuestion.objects.filter(template__in=templates, question__in=questions_by_categories).values_list('question_id')            
        else:
            question_ids = TemplateQuestion.objects.filter(template__in=templates).values_list('question_id')  

        questions = Question.objects.filter(id__in=question_ids)
        answers = AnswerReference.objects.filter(is_callout__exact=is_callout, jurisdiction__exact=juris, question__in=questions, is_current__exact=is_current).exclude(rating_status__iexact="D", approval_status__iexact='R'); 

        return answers           
        
    def set_approval_status(self, entity_id, action_category):
        if action_category == 'RequirementFlag':
            approval_status = 'F'
            
        answer_reference_obj = AnswerReference.objects.get(id=entity_id)
        answer_reference_obj.approval_status = 'F'          # Flagged
        answer_reference_obj.save()
        
        return answer_reference_obj
        
    def get_visibility_matrix(self, login, has_previously_visible_answer):
        
        visibility_matrix = {}
        if login == False and has_previously_visible_answer == False:
            visibility_matrix['U'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'hide'
            by_approal_status['A'] = 'hide'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'hide'               
            visibility_matrix['U'] = by_approal_status

            visibility_matrix['C'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show'
            by_approal_status['A'] = 'show'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'show'               
            visibility_matrix['C'] = by_approal_status            
            
            visibility_matrix['D'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'hide'
            by_approal_status['A'] = 'hide'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'hide'               
            visibility_matrix['D'] = by_approal_status    
            
        elif login == False and has_previously_visible_answer == True:
            
            visibility_matrix['U'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show_previous_answer_with_vopu_link'
            by_approal_status['A'] = 'show_previous_answer_with_vopu_link'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show_previous_answer_with_vopu_link'               
            visibility_matrix['U'] = by_approal_status

            visibility_matrix['C'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show'
            by_approal_status['A'] = 'show'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show'               
            visibility_matrix['C'] = by_approal_status            
            
            visibility_matrix['D'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show_previous_answer'
            by_approal_status['A'] = 'show_previous_answer'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show_previous_answer'               
            visibility_matrix['D'] = by_approal_status              
    
   
        elif login == True and has_previously_visible_answer == False:
            
            visibility_matrix['U'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show_as_unconfirmed'
            by_approal_status['A'] = 'show_as_unconfirmed'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'show_as_unconfirmed'                 
            visibility_matrix['U'] = by_approal_status

            visibility_matrix['C'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show'
            by_approal_status['A'] = 'show'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'show'                 
            visibility_matrix['C'] = by_approal_status            
            
            visibility_matrix['D'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'hide'
            by_approal_status['A'] = 'hide'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'hide'            
            visibility_matrix['D'] = by_approal_status                
                               
        elif login == True and has_previously_visible_answer == True:
            
            visibility_matrix['U'] = {}            
            by_approal_status = {}
            by_approal_status['P'] = 'show_previous_answer_with_vopu_link'
            by_approal_status['A'] = 'show_previous_answer_with_vopu_link'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show_previous_answer_with_vopu_link'            
            visibility_matrix['U'] = by_approal_status

            visibility_matrix['C'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show'
            by_approal_status['A'] = 'show'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show'            
            visibility_matrix['C'] = by_approal_status            
            
            visibility_matrix['D'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show_previous_answer'
            by_approal_status['A'] = 'show_previous_answer'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show_previous_answer'            
            visibility_matrix['D'] = by_approal_status             
                
        return visibility_matrix
    
    def get_callout_visibility_matrix(self, login, has_previously_visible_answer):
        
        visibility_matrix = {}
        if login == False and has_previously_visible_answer == False:
            visibility_matrix['U'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'hide'
            by_approal_status['A'] = 'hide'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'hide'            
            visibility_matrix['U'] = by_approal_status

            visibility_matrix['C'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show'
            by_approal_status['A'] = 'show'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'show'            
            visibility_matrix['C'] = by_approal_status            
            
            visibility_matrix['D'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'hide'
            by_approal_status['A'] = 'hide'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'hide'            
            visibility_matrix['D'] = by_approal_status    
            
        elif login == False and has_previously_visible_answer == True:
            
            visibility_matrix['U'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show_previous_answer_with_vopu_link'
            by_approal_status['A'] = 'show_previous_answer_with_vopu_link'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show_previous_answer_with_vopu_link'            
            visibility_matrix['U'] = by_approal_status

            visibility_matrix['C'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show'
            by_approal_status['A'] = 'show'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show'            
            visibility_matrix['C'] = by_approal_status            
            
            visibility_matrix['D'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show_previous_answer'
            by_approal_status['A'] = 'show_previous_answer'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show_previous_answer'            
            visibility_matrix['D'] = by_approal_status              
    
   
        elif login == True and has_previously_visible_answer == False:
            
            visibility_matrix['U'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show_as_unconfirmed'
            by_approal_status['A'] = 'show_as_unconfirmed'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'show_as_unconfirmed'            
            visibility_matrix['U'] = by_approal_status

            visibility_matrix['C'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show'
            by_approal_status['A'] = 'show'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'show'            
            visibility_matrix['C'] = by_approal_status            
            
            visibility_matrix['D'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'hide'
            by_approal_status['A'] = 'hide'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'hide'            
            visibility_matrix['D'] = by_approal_status                
                               
        elif login == True and has_previously_visible_answer == True:
            
            visibility_matrix['U'] = {}            
            by_approal_status = {}
            by_approal_status['P'] = 'show_previous_answer_with_vopu_link'
            by_approal_status['A'] = 'show_previous_answer_with_vopu_link'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show_previous_answer_with_vopu_link'            
            visibility_matrix['U'] = by_approal_status

            visibility_matrix['C'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show'
            by_approal_status['A'] = 'show'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show'            
            visibility_matrix['C'] = by_approal_status            
            
            visibility_matrix['D'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show_previous_answer'
            by_approal_status['A'] = 'show_previous_answer'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show_previous_answer'            
            visibility_matrix['D'] = by_approal_status             
                
        return visibility_matrix
    
    def get_info_visibility_matrix(self, login, has_previously_visible_answer):
        
        visibility_matrix = {}
        if login == False and has_previously_visible_answer == False:
            visibility_matrix['U'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'hide'
            by_approal_status['A'] = 'hide'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'hide'            
            visibility_matrix['U'] = by_approal_status

            visibility_matrix['C'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show'
            by_approal_status['A'] = 'show'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'show'            
            visibility_matrix['C'] = by_approal_status            
            
            visibility_matrix['D'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'hide'
            by_approal_status['A'] = 'hide'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'hide'            
            visibility_matrix['D'] = by_approal_status    
            
        elif login == False and has_previously_visible_answer == True:
            
            visibility_matrix['U'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show_previous_answer_with_vopu_link'
            by_approal_status['A'] = 'show_previous_answer_with_vopu_link'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show_previous_answer_with_vopu_link'            
            visibility_matrix['U'] = by_approal_status

            visibility_matrix['C'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show'
            by_approal_status['A'] = 'show'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show'            
            visibility_matrix['C'] = by_approal_status            
            
            visibility_matrix['D'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show_previous_answer'
            by_approal_status['A'] = 'show_previous_answer'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show_previous_answer'            
            visibility_matrix['D'] = by_approal_status              
    
   
        elif login == True and has_previously_visible_answer == False:
            
            visibility_matrix['U'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show_as_unconfirmed'
            by_approal_status['A'] = 'show_as_unconfirmed'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'show_as_unconfirmed'            
            visibility_matrix['U'] = by_approal_status

            visibility_matrix['C'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show'
            by_approal_status['A'] = 'show'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'show'            
            visibility_matrix['C'] = by_approal_status            
            
            visibility_matrix['D'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'hide'
            by_approal_status['A'] = 'hide'
            by_approal_status['R'] = 'hide'
            by_approal_status['F'] = 'hide'            
            visibility_matrix['D'] = by_approal_status                
                               
        elif login == True and has_previously_visible_answer == True:
            
            visibility_matrix['U'] = {}            
            by_approal_status = {}
            by_approal_status['P'] = 'show_previous_answer_with_vopu_link'
            by_approal_status['A'] = 'show_previous_answer_with_vopu_link'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show_previous_answer_with_vopu_link'            
            visibility_matrix['U'] = by_approal_status

            visibility_matrix['C'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show'
            by_approal_status['A'] = 'show'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show'            
            visibility_matrix['C'] = by_approal_status            
            
            visibility_matrix['D'] = {}
            by_approal_status = {}
            by_approal_status['P'] = 'show_previous_answer'
            by_approal_status['A'] = 'show_previous_answer'
            by_approal_status['R'] = 'show_previous_answer'
            by_approal_status['F'] = 'show_previous_answer'            
            visibility_matrix['D'] = by_approal_status             
                
        return visibility_matrix
    
    
            
    def check_requirement_visibility(self, login, ans_ref_id):
        
        ans_ref_obj = AnswerReference.objects.get(id=ans_ref_id)
        rating_status = ans_ref_obj.rating_status
        approval_status = ans_ref_obj.approval_status
                        
        has_previously_visible_answer = self.check_if_has_previously_visible_answer(ans_ref_obj)   
      
        visibility_matrix = self.get_visibility_matrix(login, has_previously_visible_answer)
        
        try:
            visibility = visibility_matrix[rating_status][approval_status]
        except:
     
            visibility = "hide"
        
        return visibility
    
    def check_callout_visibility(self, login, ans_ref_id):
        
        ans_ref_obj = AnswerReference.objects.get(id=ans_ref_id)
        rating_status = ans_ref_obj.rating_status
        approval_status = ans_ref_obj.approval_status
                        
        has_previously_visible_answer = self.check_if_has_previously_visible_answer(ans_ref_obj)   
         
        visibility_matrix = self.get_callout_visibility_matrix(login, has_previously_visible_answer)
        
        try:
            visibility = visibility_matrix[rating_status][approval_status]
        except:
        
            visibility = "hide"
        
        return visibility
    
    def check_info_visibility(self, login, ans_ref_id):
        
        ans_ref_obj = AnswerReference.objects.get(id=ans_ref_id)
        rating_status = ans_ref_obj.rating_status
        approval_status = ans_ref_obj.approval_status
                        
        has_previously_visible_answer = self.check_if_has_previously_visible_answer(ans_ref_obj)   
      
        visibility_matrix = self.get_info_visibility_matrix(login, has_previously_visible_answer)
        
        try:
            visibility = visibility_matrix[rating_status][approval_status]
        except:
       
            visibility = "hide"
        
        return visibility            
    
    def check_if_has_previously_visible_answer(self, ans_ref_obj):
        jurisdiction_id = ans_ref_obj.jurisdiction_id
        question_id = ans_ref_obj.question_id
        is_callout = ans_ref_obj.is_callout
        jurisdiction = Jurisdiction.objects.get(id=jurisdiction_id)        
        question = Question.objects.get(id=question_id)
        ans_ref_objs = AnswerReference.objects.filter(jurisdiction__exact=jurisdiction, question__exact=question, is_callout__exact=is_callout, rating_status__exact='C').exclude(approval_status__exact='R')

        if ans_ref_objs:
            return True
        else:
            # no confirmed answer.  let's look at the unconfirmed, per later request not to replace the unconfirmed answer by any unconfirmed answer.
            ans_ref_objs = AnswerReference.objects.filter(jurisdiction__exact=jurisdiction, question__exact=question, is_callout__exact=is_callout, rating_status__exact='U').exclude(approval_status__exact='R').exclude(id=ans_ref_obj.id)
            if len(ans_ref_objs) > 0:
                return True
            else:
                return False
            
        return False
        
    def get_previously_visible_answer(self, ans_ref_obj):
        jurisdiction_id = ans_ref_obj.jurisdiction_id
        question_id = ans_ref_obj.question_id
        is_callout = ans_ref_obj.is_callout
        jurisdiction = Jurisdiction.objects.get(id=jurisdiction_id)        
        question = Question.objects.get(id=question_id)
        ans_ref_objs = AnswerReference.objects.filter(jurisdiction__exact=jurisdiction, question__exact=question, is_callout__exact=is_callout, rating_status__exact='C').exclude(approval_status__exact='R').order_by('create_datetime')

        if ans_ref_objs:
            return ans_ref_objs[0]
        else:
            # no confirmed answer.  let's look at the unconfirmed, per later request not to replace the unconfirmed answer by any unconfirmed answer.
            ans_ref_objs = AnswerReference.objects.filter(jurisdiction__exact=jurisdiction, question__exact=question, is_callout__exact=is_callout, rating_status__exact='U').exclude(approval_status__exact='R').exclude(id=ans_ref_obj.id).order_by('create_datetime')
            if len(ans_ref_objs) > 0:   # to eleminate itself
                return ans_ref_objs[0]
            else:
                return False    
            
        return False    
        
    def get_rating_status_change_message(self, entity_name, entity_id, prev_msg, new_msg, action_category):
        msg = ''

        if entity_name.lower() == 'requirement' and action_category.lower() == 'voterequirement':
        
            if prev_msg.lower() != 'c' and new_msg.lower() == 'c':
       
                msg = "There are now enough votes for this item and it is now Confirmed.  Thank you!"
                
            if prev_msg.lower() != 'd' and new_msg.lower() == 'd':
                msg = "There are enough votes to dispute this item and it is now hidden.  Thank you!"
                
        if entity_name.lower() == 'callout' and action_category.lower() == 'votecallout':
            
            if prev_msg.lower() != 'c' and new_msg.lower() == 'c':
              
                msg = "There are now enough votes for this item and it is now Confirmed.  Thank you!"
                
            if prev_msg.lower() != 'd' and new_msg.lower() == 'd':
                msg = "There are enough votes to dispute this item and it is now hidden.  Thank you!"       
                
        if entity_name.lower() == 'info' and action_category.lower() == 'voteinfo':
           
            if prev_msg.lower() != 'c' and new_msg.lower() == 'c':
               
                msg = "There are now enough votes for this item and it is now Confirmed.  Thank you!"
                
            if prev_msg.lower() != 'd' and new_msg.lower() == 'd':
                msg = "There are enough votes to dispute this item and it is now hidden.  Thank you!"                   
                
        return msg
                
    
    def save_answer(self, question_obj, answer, juris, action_category_obj, user, is_callout):
        
        #juris = Jurisdiction.objects.get(id=jid)
       
        #question_obj = Question.objects.get(id=qid)
        answerreferences = AnswerReference.objects.filter(question__exact=question_obj, jurisdiction__exact=juris, is_callout__exact=is_callout, is_current__exact=1)  
        if answerreferences:
            for answer_ref_obj in answerreferences:
                answer_ref_obj.is_current = 0
                answer_ref_obj.modify_datetime = datetime.datetime.now()
              
                answer_ref_obj.save()

        encoded_txt = answer.encode('utf-8')           
       
        save_n_approved = False
        if user.is_superuser == 1:
            if question_obj.has_multivalues == 1:
                save_n_approved = True
            elif len(answerreferences) == 0:   # if entered by superadmin and if there is no existing suggestion -> automatic approval
                save_n_approved = True
            else:
                save_n_approved = False
        else:     
            save_n_approved = False
            
        if save_n_approved == True:
            approval_status = 'A'
        else:
            approval_status = 'P'
            
        answerreference = AnswerReference(question_id = question_obj.id, value = encoded_txt, jurisdiction_id = juris.id, is_callout = is_callout, rating_status='U', approval_status=approval_status, is_current=1, creator_id=user.id, status_datetime = datetime.datetime.now(), modify_datetime = datetime.datetime.now())            
        
        answerreference.save()
      
        #category_name = action_key
        #entity_name='AnswerReference'
        #data = str(answer)
        action_obj = Action()
        action_obj.save_action(category_name, data, answerreference, entity_name, user.id, juris)      
        
        org_members = OrganizationMember.objects.filter(user=user, status = 'A', organization__status = 'A')
        if len(org_members) > 0:
            org = org_members[0].organization
            juris.last_contributed_by_org = org
                
        juris.last_contributed = datetime.datetime.now()
        juris.last_contributed_by = user
        juris.save()
   
        return answerreference      
    
    def save_question_n_value(self, question_txt, value, jid, cid, user):
        # save to Question
        encoded_txt = question_txt.encode('utf-8')        
       
        question = Question(question=encoded_txt, form_type="TA", category_id=cid)
        question.save()
  
        # save to template question
        #template_question = TemplateQuestion(template_id=tid, question_id=question.id)
        #template_question.save()
    
        # save to answer refereence
        action_key = "AddRequirement"
        is_callout = 0
        #answer_reference_class_obj = AnswerReference()
        answerreference = self.save_answer(question.id, value, jid, action_key, user, is_callout)
        # save to AnswerReference
      
        return answerreference
    
    def answer_file_type(self):
        if self.question.form_type == 'F':
            import os
            asw = str(self.file_upload)
            filename, extension = os.path.splitext(asw)
            image_type_array = ['.jpg', '.jpeg', '.gif', '.bmp', '.png', '.tiff']
     
            if image_type_array.count(extension) > 0:
                return True
            return False
        return False      
    
    def get_jurisdiction_data(self,jurisdiction_id, question):
        answer = {} 
        jurisdiction = Jurisdiction.objects.get(id=jurisdiction_id)
        questions = Question.objects.filter(question__iexact=question)
        answer['has_answer'] = False
        if questions and jurisdiction:
            question = questions[0]
            answer['question'] = question
            answer_references = AnswerReference.objects.filter(jurisdiction__exact=jurisdiction, question__exact=question).order_by('-create_datetime') # temp solution: order by desc, then use the last one.  in the future must use the confirmed/approval logic 
        
            if answer_references:
                answer_reference = answer_references[0]
                answer_value = answer_reference.value
                answer = json.loads(answer_value)
                answer['contributor'] = answer_reference.creator
                answer['contributor_id'] = answer_reference.creator_id              
                answer['question'] = question
                datetime_util_obj = DatetimeHelper(jurisdiction.last_contributed)
                answer['contribution_date'] = datetime_util_obj.showStateTimeFormat(jurisdiction.state)                  
                #answer['contribution_date'] = answer_reference.create_datetime
                answer['has_answer'] = True
            else:
                answer = {}
                answer['question'] = question
                answer['has_answer'] = False
    
        return answer
        
        #def save(self, *args, **kwargs):
        #    super(AnswerReference, self).save(*args, **kwargs)
        
class Comment(models.Model):
    COMMENT_TYPE_CHOICES = (
        ('JC', 'Jurisdiction Comment'),
        ('RC', 'Requirement Comment'),
        ('RF', 'Requirement Flag'),
        ('COF', 'Callout Flag'),    
        #('CC', 'Comment Comment'), #comment on a comment, no longer a type, use parent_comment field instead!
        ('CF', 'Comment Flag'), #flag a comment
        ('COC', 'Callout Comment'),   
    )
    jurisdiction = models.ForeignKey(Jurisdiction, blank=True, null=True, db_index=True)
    entity_name = models.CharField(max_length=32, blank=True, null=True, db_index=True) #Django entity name, like "AnswerReference"
    entity_id = models.PositiveIntegerField(blank=True, null=True, db_index=True)
    user = models.ForeignKey(User, blank=True, null=True)
    comment_type = models.CharField(choices=COMMENT_TYPE_CHOICES, max_length=8, blank=True, null=False, db_index=True, default="")
    comment = models.TextField(blank=True, null=True)
    parent_comment = models.ForeignKey('self', related_name='parent_reference', blank=True, null=True)
    rating = models.IntegerField(blank=True, null=True, db_index=True) #rating of this comment, highest listed first
    rating_status = models.CharField(choices=RATING_STATUS_CHOICES, max_length=8, blank=True, null=False, db_index=True, default="U")
    approval_status = models.CharField(choices=APPROVAL_STATUS_CHOICES, max_length=8, blank=True, null=False, db_index=True, default="P")
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    class Meta:
        app_label = 'website'
    
    # entity_name and entity_id represent the entity to which the comments are for.  ex: answerreference, or comment itself.
    def save_comment(self, entity_id, entity_name, comment_type, comment_txt, user):
   
        comment = Comment(entity_id = entity_id, entity_name = entity_name, comment_type = comment_type, comment=comment_txt, user_id=user.id)

        comment.save()
    

        return comment
    def get_son_comments(self):
        comments = Comment.objects.filter(parent_comment = self).order_by('create_datetime')
        return comments
    
    def comment_level(self):
        if self.parent_comment == None:
            return 1
        if self.parent_comment.parent_comment == None:
            return 2
        if self.parent_comment.parent_comment.parent_comment == None:
            return 3
        return 4
    
    def get_comment_time(self):
        datetime_util_obj = DatetimeHelper(self.create_datetime)
        return datetime_util_obj.showStateTimeFormat(self.jurisdiction.state)
    
#track viewing of comments by user
class UserCommentView(models.Model):
    user = models.ForeignKey(User, blank=True, null=True)
    jurisdiction = models.ForeignKey(Jurisdiction, blank=True, null=True, db_index=True)
    entity_name = models.CharField(max_length=32, blank=True, null=True, db_index=True) #Django entity name, like "AnswerReference"
    entity_id = models.PositiveIntegerField(blank=True, null=True, db_index=True) #entity id that the comment was for
    last_comment = models.ForeignKey(Comment, blank=True, null=True) #the last comment for that entity id at the time of viewing
    comments_count = models.IntegerField(blank=True, null=True) #total count of comments at the time of viewing, to calculate how many new later
    view_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True) #when the comments were viewed, need to be updated every time viewed
    
    class Meta:
        app_label = 'website'
    
    
class View(models.Model):
    name = models.CharField(max_length=128, blank=True, null=True, db_index=True)
    description = models.TextField(blank=True, null=True)
    reviewed = models.BooleanField(default=False)
    accepted = models.BooleanField(default=False)
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    modify_datetime = models.DateTimeField(blank=True, null=True)
    def __unicode__(self):
        return self.name        
    class Meta:
        app_label = 'website'
        
class ViewOrgs(models.Model):
    view = models.ForeignKey(View, db_index=True)
    organization = models.ForeignKey(Organization, db_index=True) 
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    modify_datetime = models.DateTimeField(blank=True, null=True)    
    def __unicode__(self):
        return self.view.name + ' - ' + str(self.organization.name)
    class Meta:
        app_label = 'website'        
        
    def get_user_accessible_views(self, user):
        accessible_views = []
        try:
            user = User.objects.get(id=user.id)
            user_orgs = OrganizationMember.objects.filter(status = 'A', organization__status = 'A', user = user)

            if len(user_orgs) > 0:
                orgs = []
                for user_org in user_orgs:
                    orgs.append(user_org.organization)
                    
                view_orgs = ViewOrgs.objects.filter(organization__in=orgs)
                if len(view_orgs) > 0:
                    for view_org in view_orgs:
                       accessible_views.append(view_org.view.name.lower())            
        except:
            pass   
        
        return  accessible_views    
        
class ViewQuestions(models.Model):
    view = models.ForeignKey(View, db_index=True)
    question = models.ForeignKey(Question, db_index=True)
    display_order = models.PositiveSmallIntegerField(blank=True, null=True)    
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    modify_datetime = models.DateTimeField(blank=True, null=True)    
    def __unicode__(self):
        return self.view.name + ' - ' + str(self.question.id)
    class Meta:
        app_label = 'website'
                       