from django.http import HttpResponseRedirect, HttpResponse, Http404

from django.template.loader import get_template
from django.template import Context, RequestContext
from website.utils.httpUtil import HttpRequestProcessor
from django.views.decorators import csrf
from dajax.core.Dajax import Dajax
from django.conf import settings as django_settings
from django.core.mail.message import EmailMessage
from django.shortcuts import render

from django.shortcuts import render_to_response
from website.utils.mathUtil import MathUtil
from website.utils.paginationUtil import PaginationUtil

from website.utils.messageUtil import MessageUtil


def get_info(request):
    data = {}
    requestProcessor = HttpRequestProcessor(request)
      
    ajax = requestProcessor.getParameter('ajax')
    if (ajax != None):
        if (ajax == 'about'):
            body = requestProcessor.decode_jinga_template(request,'website/blocks/about.html', data, '') 
            dajax.assign('#main_content','innerHTML', body)    
            return HttpResponse(dajax.json())  
        
        return HttpResponse(dajax.json())  

    return requestProcessor.render_to_response(request,'website/jurisdictions/jurisdiction_state_browse.html', data, '')
    

