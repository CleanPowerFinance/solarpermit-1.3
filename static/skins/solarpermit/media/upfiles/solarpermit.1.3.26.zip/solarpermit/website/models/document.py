import datetime
from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
from website.models import Region, Jurisdiction

class DocumentCategory(models.Model):
    name = models.CharField(max_length=64, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    def __unicode__(self):
        return self.name
    class Meta:
        app_label = 'website'

class Document(models.Model):
    title = models.CharField(max_length=128, blank=True, null=True, db_index=True)
    description = models.TextField(blank=True, null=True)
    file_name = models.CharField(max_length=64, blank=True, null=True, db_index=True) #original file name
    file_path = models.FileField(upload_to='docs')
    region = models.ForeignKey(Region, blank=True, null=True, db_index=True)
    jurisdiction = models.ForeignKey(Jurisdiction, blank=True, null=True, db_index=True)
    reviewed = models.BooleanField(default=False, db_index=True)
    accepted = models.BooleanField(default=False, db_index=True)
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    modify_datetime = models.DateTimeField(blank=True, null=True)
    def __unicode__(self):
        return self.title
    class Meta:
        app_label = 'website'
