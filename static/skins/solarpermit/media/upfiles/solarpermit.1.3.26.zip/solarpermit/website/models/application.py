import datetime
from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
from website.models import Jurisdiction, Address, Template, Question

APP_STATUS_CHOICES = (
    ('NS', 'Not Submitted'),
    ('S', 'Submitted'),
    ('A', 'Approved'),
    ('R', 'Rework'),
    ('D', 'Declined'),
)

class Application(models.Model):
    jurisdiction = models.ForeignKey(Jurisdiction, blank=True, null=True, db_index=True)
    applicant = models.ForeignKey(User, blank=True, null=True, db_index=True)
    template = models.ForeignKey(Template, blank=True, null=True, db_index=True)
    # TODO: add project info
    address = models.ForeignKey(Address, blank=True, null=True)
    current_status = models.CharField(choices=APP_STATUS_CHOICES, max_length=8, blank=True, null=True, db_index=True)
    status_datetime = models.DateTimeField(blank=True, null=True)
    def __unicode__(self):
        output = str(self.id)
        if self.applicant != None:
            if self.applicant.username != None:
                output = self.applicant.username
        if self.address != None:
            output += ', '+self.address
        return output
    class Meta:
        app_label = 'website'

class ApplicationHistory(models.Model):
    application = models.ForeignKey(Application, db_index=True)
    status = models.CharField(choices=APP_STATUS_CHOICES, max_length=8, blank=True, null=True, db_index=True)
    status_by = models.ForeignKey(User, blank=True, null=True)
    status_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    def __unicode__(self):
        if self.status != None:
            return self.application.__unicode__()+', '+self.status
        else:
            return self.application.__unicode__()
    class Meta:
        app_label = 'website'

#answers for a transaction, like a contractor's application for solar permit in San Francisco for a specific address
class ApplicationAnswer(models.Model):
    application = models.ForeignKey(Application, db_index=True)
    template = models.ForeignKey(Template, db_index=True)
    question = models.ForeignKey(Question, db_index=True)
    value = models.TextField(blank=True, null=True) #convert all values to text
    file_upload = models.FileField(upload_to='answer_ref_files', blank=True, null=True)
    create_datetime = models.DateTimeField(auto_now_add=True, blank=True, null=True)
    modify_datetime = models.DateTimeField(blank=True, null=True)
    def __unicode__(self):
        return self.value
    class Meta:
        app_label = 'website'
    