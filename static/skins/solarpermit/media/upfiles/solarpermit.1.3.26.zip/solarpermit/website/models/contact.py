import datetime
from django.db import models
from django.contrib.auth.models import User
from django.conf import settings
from django.contrib.localflavor.us.us_states import STATE_CHOICES
from django.contrib.localflavor.us.models import PhoneNumberField

class Address(models.Model):
    address1 = models.CharField(max_length=255, blank=True, null=True)
    address2 = models.CharField(max_length=255, blank=True, null=True)
    city = models.CharField(max_length=128, blank=True, null=True)
    state = models.CharField(choices=STATE_CHOICES, max_length=8, blank=True, null=True)
    zip_code = models.CharField(max_length=32, blank=True, null=True)
    latitude = models.DecimalField(max_digits=10, decimal_places=7, blank=True, null=True)
    longitude = models.DecimalField(max_digits=10, decimal_places=7, blank=True, null=True)
    def __unicode__(self):
        return self.address1+', '+self.address2+', '+self.city+', '+self.state+' '+self.zip_code
    class Meta:
        app_label = 'website'

class Person(models.Model):
    user = models.ForeignKey(User, blank=True, null=True)
    first_name = models.CharField(max_length=64, blank=True, null=True, db_index=True)
    last_name = models.CharField(max_length=64, blank=True, null=True, db_index=True)
    phone_primary = PhoneNumberField(blank=True, null=True) #can be for office number
    phone_secondary = PhoneNumberField(blank=True, null=True)
    phone_mobile = PhoneNumberField(blank=True, null=True)
    email = models.EmailField(blank=True, null=True)
    def __unicode__(self):
        return self.first_name+' '+self.last_name
    class Meta:
        app_label = 'website'

ADDRESS_TYPE_CHOICES = (
    ('H', 'Home'),
    ('W', 'Work'),
    ('HQ', 'Headquarter'),
    ('B', 'Branch'),
)

class PersonAddress(models.Model):
    person = models.ForeignKey(Person, blank=True, null=True)
    address = models.ForeignKey(Address, blank=True, null=True)
    address_type = models.CharField(choices=ADDRESS_TYPE_CHOICES, max_length=8, blank=True, null=True, db_index=True)
    display_order = models.PositiveSmallIntegerField(blank=True, null=True)
    class Meta:
        app_label = 'website'
    