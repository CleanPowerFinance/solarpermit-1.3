#from server.website.models import JurisdictionContributor, Action, ActionCategory, AnswerReference, Question, OrganizationMember
#from askbot.conf import settings as askbot_settings
from django.conf import settings as django_settings
from website.utils.mathUtil import MathUtil
from django.contrib.auth.models import User
from website.models import OrganizationMember, Organization, Jurisdiction, UserDetail
from website.models import ActionCategory, Action, ReactionCategory, Reaction
from website.models import AnswerReference, Question, QuestionCategory, Comment
from website.models import RatingCategory, UserRating, OrganizationRating, JurisdictionContributor

class ContributionHelper():
    
    def save_action(self, action_category_name, data, entity_id, entity_name, user_id, jurisdiction_id ):
        print "save_action"
        #data = str(data)
        entity_category_id = 0
        action_category = ActionCategory.objects.filter(name__iexact=action_category_name)
        try:
            entity_category_id = action_category[0].id
        except:
            entity_category_id = 0
        if action_category_name == "FlagComment":           #ok
            action_data = "Report: " + data
        elif action_category_name == "FlagRequirement":     #ok
            action_data = "Report: " + data
        elif action_category_name == "FlagCallout":     #ok
            action_data = "Report: " + data          
        elif action_category_name == "FlagInfo":     #ok
            action_data = "Report: " + data    
                          
        elif action_category_name == "CommentComment":      #ok
            action_data = "Comment: " + data
        elif action_category_name == "CommentRequirement":  #ok
            action_data = "Comment: " + data
        elif action_category_name == "CommentCallout":  #ok
            action_data = "Comment: " + data            
        elif action_category_name == "CommentInfo":  #ok
            action_data = "Comment: " + data      
                        
        elif action_category_name == "AddRequirement":
            action_data = "Answer: " + data     
        elif action_category_name == "UpdateRequirement":
            action_data = "Answer: " + data 
                   
        elif action_category_name == "AddCallout":
            action_data = "Callout: " + data      
        elif action_category_name == "UpdateCallout":
            action_data = "Callout: " + data       

        elif action_category_name == "AddInfo":
            action_data = "Info: " + data      
        elif action_category_name == "UpdateInfo":
            action_data = "Info: " + data       
                                            
        elif action_category_name == "VoteRequirement":
            action_data = "Vote: " + data.title() 
        elif action_category_name == "VoteComment":
            action_data = "Vote: " + data.title() 
        elif action_category_name == "VoteCallout":
            action_data = "Vote: " + data.title() 
        elif action_category_name == "VoteInfo":
            action_data = "Vote: " + data.title()             
            
        if entity_name == 'AnswerReference' or entity_name == 'Requirement' or entity_name == 'Callout' or entity_name == 'Info':
            print 'entity id :: ' + str(entity_id)
            entity = AnswerReference.objects.get(id=entity_id)
            print 'question id :: ' + str(entity.question_id)
            question = Question.objects.get(id=entity.question_id)
            print 'question category id :: ' + str(question.category_id) 
            entity_category_id = question.category_id     
        else:
            # look up the question category of the item to which comment is associated.
            # assuming the entity name is Comment
            if entity_name == 'Comment':
                print 'entity id :: ' + str(entity_id)
                entity_obj = Comment.objects.get(id=entity_id)
                parent_entity_id = entity_obj.entity_id
                parent_entity_name = entity_obj.entity_name
                if parent_entity_name == 'Requirement' or parent_entity_name == 'Callout' or parent_entity_name == 'Info':
                    print 'parent_entity_id :: ' + str(parent_entity_id)
                    parent_entity = AnswerReference.objects.get(id=parent_entity_id)
                    print 'question id :: ' + str(parent_entity.question_id)
                    question = Question.objects.get(id=parent_entity.question_id)
                    print 'question category id :: ' + str(question.category_id) 
                    entity_category_id = question.category_id     
                
        if entity_category_id > 0:
            print "jurisdiciton :: " + str(jurisdiction_id)
            print "user_id :: " + str(user_id)
            print action_category[0].id        
             
            action_obj = Action.objects.create(category_id=action_category[0].id, entity_id=entity_id, data=action_data, entity_name=entity_name, user_id=user_id, scale=action_category[0].points, jurisdiction_id=jurisdiction_id, question_category_id=entity_category_id)
            
            print "track contribution :: "
            print "scale :: " + str(action_obj.scale)
            print "jurisdiciton :: " + str(jurisdiction_id)
            print "user_id :: " + str(user_id)
            self.track_contributions(action_obj.scale, jurisdiction_id, entity_category_id, user_id)
        
        return action_obj    
    
    def save_reaction(self, entity_name, entity_id, action_obj, new_rating_status, entity_category_id, user_id, jurisdiction_id ):
        print "save_reaction"
        print "entity name :: " + str(entity_name)
        
        if new_rating_status == 'C':
            reaction_category_name = entity_name+'Confirmed'
        elif new_rating_status == 'D':
            reaction_category_name = entity_name+'Disputed'
        elif new_rating_status == 'U':
            reaction_category_name = entity_name+'Unconfirmed'
        elif new_rating_status == 'R':
            reaction_category_name = entity_name+'Removed'
                        
        print "reaction_category_name :: " + reaction_category_name
        reaction_category = ReactionCategory.objects.filter(name__iexact=reaction_category_name)      
        if reaction_category:      
            print "reaction_category found "
            answer = AnswerReference.objects.get(id=entity_id) 
            print "answer reference found "       
            
            data = action_obj.data + " >> " + reaction_category_name 
            print "data :: " + data           
            reaction_obj = Reaction.objects.create(category_id=reaction_category[0].id, action_id=action_obj.id, data=data, user_id=user_id, scale=reaction_category[0].points, jurisdiction_id=jurisdiction_id, question_category_id=entity_category_id)
            print "reaction saved"
            self.track_contributions(reaction_category[0].points, jurisdiction_id, entity_category_id, answer.creator_id)   
            print "tracking contribution done"
            
    
    def track_contributions(self, points, jurisdiction_id, entity_category_id, user_id): 
        jurisdiction = Jurisdiction.objects.get(id=jurisdiction_id)
        question_category = QuestionCategory.objects.get(id=entity_category_id)         
        print ">>>>>>>>>>>>>>>>> get org from user" + str(user_id)
        # get org from user
        
        try:
            user = User.objects.get(id=user_id)
            print "here"
            rating_category_objs = RatingCategory.objects.filter(name__iexact='Points')
            rating_category_obj = rating_category_objs[0]
                
            print "before maintaining user rating "
            # maintain user rating      
            user_rating_objs = UserRating.objects.filter(user__exact=user, category__exact=rating_category_obj)
            if user_rating_objs:
                user_rating_obj = user_rating_objs[0]
                user_rating_obj.scale = user_rating_obj.scale + points
                user_rating_obj.save()
            else:
                UserRating.objects.create(user_id=user_id, category_id=rating_category_obj.id, scale=points)     
                
            print "before maintain User Contribution"            
            # maintain User Contribution
            user_contributor_objs = JurisdictionContributor.objects.filter(jurisdiction__exact=jurisdiction, question_category__exact=question_category, user__exact=user)
            if user_contributor_objs:
                user_contributor_obj = user_contributor_objs[0]
                user_contributor_obj.points = user_contributor_obj.points + points
                user_contributor_obj.save()
            else:
                JurisdictionContributor.objects.create(jurisdiction_id=jurisdiction_id, question_category_id=entity_category_id, user_id=user_id, points=points)
                                       
                
            try:
                org_ids = OrganizationMember.objects.filter(user__exact=user).distinct().values_list('organization_id')
                
                print "beore maintain org rating "   
                # maintain org rating
                if org_ids:
                    print "for loop commends here"
                    for org_id in org_ids:
                        organization_id = org_id[0]
                        print "organization_id :: " + str(organization_id)
                        org = Organization.objects.get(id=organization_id)
                        print "org found :: "
                        org_rating_objs = OrganizationRating.objects.filter(organization__exact=org, category__exact=rating_category_obj)
                        print "org_rating found"
                        if org_rating_objs:
                            print "incrementng org rating"
                            org_rating_obj = org_rating_objs[0]
                            org_rating_obj.scale = org_rating_obj.scale + points
                            org_rating_obj.save()
                        else:
                            print "save new org rating record"
                            OrganizationRating.objects.create(organization_id=organization_id, category_id=rating_category_obj.id, scale=points) 
                            
    
                print "before maintain Org Contribution"
                # maintain Org Contribution
                if org_ids:
                    for org_id in org_ids:        
                        organization_id = org_id[0]
                        org = Organization.objects.get(id=organization_id)
                        org_contributor_objs = JurisdictionContributor.objects.filter(jurisdiction__exact=jurisdiction, question_category__exact=question_category, organization__exact=org)
                        if org_contributor_objs:
                            org_contributor_obj = org_contributor_objs[0]
                            org_contributor_obj.points = org_contributor_obj.points + points
                            org_contributor_obj.save()
                        else:
                            JurisdictionContributor.objects.create(jurisdiction_id=jurisdiction_id, question_category_id=entity_category_id, organization_id=organization_id, points=points) 
                    
                print "before maintain org contribution per jurisdiction"
                # maintain org contribution per jurisdiction
                if org_ids:
                    for org_id in org_ids:     
                        organization_id = org_id[0]
                        org = Organization.objects.get(id=organization_id)                                  
                        jur_org_contributor_objs = JurisdictionContributor.objects.filter(jurisdiction__exact=jurisdiction, organization__exact=org, question_category__isnull=True, user__isnull=True)
                        if jur_org_contributor_objs:
                            jur_org_contributor_obj = jur_org_contributor_objs[0]
                            jur_org_contributor_obj.points = jur_org_contributor_obj.points + points
                            jur_org_contributor_obj.save()
                        else:
                            JurisdictionContributor.objects.create(jurisdiction_id=jurisdiction_id, organization_id=organization_id, points=points)                                                   
                
                print "before run"
            except: 
                print "cannot find the orgs for user."
        except:
            print "cannot find the user. ignor contribution"
            
        return True
    

        
        
    def get_org_jurisdiction_contributors(self, jurisdiction_id, top):
        jurisdiction = Jurisdiction.objects.get(id=jurisdiction_id)
                
        if top > 0:
            orgContributors = JurisdictionContributor.objects.filter(jurisdiction__exact=jurisdiction, question_category__isnull=True, user__isnull=True).order_by('-points')
        else:
            orgContributors = JurisdictionContributor.objects.filter(jurisdiction__exact=jurisdiction, question_category__isnull=True, user__isnull=True).order_by('-points')
        
        counter = 0
        org_dict = {}
        if orgContributors:
            for orgContributor in orgContributors:
                if orgContributor.organization_id != None:
                    org = Organization.objects.get(id=orgContributor.organization_id)
                    if org != None:
                        org_dict[org.id] = org
                        counter = counter + 1
                        if counter > 1: break                        
        return org_dict.values() 
        
    def get_org_entity_contributors(self, jurisdiction, entity_category, top=3):
        #jurisdiction = Jurisdiction.objects.get(id=jurisdiction_id)
        #question_category = QuestionCategory.objects.get(id=entity_category_id)  
                
        if top > 0:
            orgContributors = JurisdictionContributor.objects.filter(jurisdiction__exact=jurisdiction, question_category__exact=entity_category, user__isnull=True).order_by('-points')[0:top]
        else:
            orgContributors = JurisdictionContributor.objects.filter(jurisdiction__exact=jurisdiction, question_category__exact=entity_category, user__isnull=True).order_by('-points')
        '''
        counter = 0
        org_dict = {}
        if orgContributors:
            for orgContributor in orgContributors:
                if orgContributor.organization_id != None:
                    org = Organization.objects.get(id=orgContributor.organization_id)
                    if org != None:
                        org_dict[org.id] = org
                        #counter = counter + 1
                        #if counter > 1: break                        
        return org_dict.values() 
        '''
            
        return orgContributors
        
    def get_user_entity_contributors(self, jurisdiction_id, entity_category_id, top):
        jurisdiction = Jurisdiction.objects.get(id=jurisdiction_id)
        question_category = QuestionCategory.objects.get(id=entity_category_id)   
        if top > 0:
            print "query with top"
            userContributors = JurisdictionContributor.objects.filter(jurisdiction__exact=jurisdiction, question_category__exact=question_category, organization__isnull=True).order_by('-points')
        else:
            print "query without tops"
            userContributors = JurisdictionContributor.objects.filter(jurisdiction__exact=jurisdiction, question_category__exact=question_category, organization__isnull=True).order_by('-points')[0:top]
        
        counter = 0
        user_dict = {}
        if userContributors:
            for userContributor in userContributors:
                if userContributor.user_id != None:
                    user = User.objects.get(id=userContributor.user_id)
                    user_dict[user.id] = user
                    counter = counter + 1
                    if counter > 2: break
        print user_dict
        return user_dict.values()