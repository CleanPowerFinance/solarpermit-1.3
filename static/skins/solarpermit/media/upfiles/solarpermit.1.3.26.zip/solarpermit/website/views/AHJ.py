import re
from django.http import HttpResponseRedirect, HttpResponse, Http404
from django.contrib.auth.decorators import login_required
from django.contrib.localflavor.us.us_states import US_STATES
from django.contrib import messages
from django.template.loader import get_template as django_get_template
from django.template import Context, RequestContext
from website.utils.httpUtil import HttpRequestProcessor
from django.views.decorators import csrf
from dajax.core.Dajax import Dajax
from django.conf import settings as django_settings
from django.core.mail.message import EmailMessage
from django.shortcuts import render

from django.shortcuts import render_to_response, redirect
from website.utils.mathUtil import MathUtil
from website.utils.paginationUtil import PaginationUtil
from website.utils.geoHelper import GeoHelper
from website.models import Jurisdiction, Zipcode, UserSearch, Question, AnswerReference, OrganizationMember, QuestionCategory, Comment, UserCommentView, Template, ActionCategory, JurisdictionContributor, Action, UserDetail, OrganizationMember
from website.models import View, ViewQuestions, ViewOrgs
from website.utils.messageUtil import MessageUtil,add_system_message,get_system_message
from website.utils.miscUtil import UrlUtil
from website.utils.fieldValidationCycleUtil import FieldValidationCycleUtil
from website.utils.datetimeUtil import DatetimeHelper
from django.contrib.auth.models import User
import json
import datetime

from BeautifulSoup import BeautifulSoup

JURISDICTION_PAGE_SIZE = 30 #page size for endless scroll


    
def jurisdiction_comment(request):
    requestProcessor = HttpRequestProcessor(request)
    user = request.user
    data = {}
    dajax = Dajax()
    ajax = requestProcessor.getParameter('ajax')
    comments_changed = requestProcessor.getParameter('comments_changed')
    if comments_changed == 'yes':
        data['comments_changed'] = 'yes'
    else:
        data['comments_changed'] = 'no'
    if (ajax != None):
        if ajax == 'open_jurisdiction_comment':
            entity_id = requestProcessor.getParameter('entity_id')
            entity_name = requestProcessor.getParameter('entity_name')
            jid = requestProcessor.getParameter('jurisdiction_id')
            try:
                jurisdiction = Jurisdiction.objects.get(id = jid)
            except:
                jurisdiction = None
            comments = Comment.objects.filter(jurisdiction = jurisdiction, entity_name = entity_name, entity_id = entity_id, parent_comment__isnull = True).order_by('-create_datetime')
            
           
            userviews = UserCommentView.objects.filter(jurisdiction = jurisdiction, entity_name = entity_name, entity_id = entity_id, user = user)
            
            temp_comments = Comment.objects.filter(jurisdiction = jurisdiction, entity_name = entity_name, entity_id = entity_id).order_by('-create_datetime')
            last_comment = None
            if len(temp_comments) > 0 :
                last_comment = temp_comments[0]
            
            has_userview = False
            if len(userviews) > 0:
                userview = userviews[0]
                if userview.last_comment != None:
                    data['userview_last_comment'] = userview.last_comment.id
                    data['userview'] = userviews[0]
                    userview.comments_count = Comment.objects.filter(jurisdiction = jurisdiction, entity_name = entity_name, entity_id = entity_id).count()
                    userview.last_comment = last_comment
                    userview.view_datetime = datetime.datetime.now()
                    userview.save()
                    has_userview = True
            if has_userview == False:
                userview = None
                data['userview'] = userview
                data['userview_last_comment'] = 0
                userview = UserCommentView()
                userview.user = user
                userview.jurisdiction = jurisdiction
                userview.entity_name = entity_name
                userview.entity_id = entity_id
                userview.comments_count = Comment.objects.filter(jurisdiction = jurisdiction, entity_name = entity_name, entity_id = entity_id).count()
                userview.last_comment = last_comment
                userview.view_datetime = datetime.datetime.now()
                userview.save()
            
            af = AnswerReference.objects.get(id = entity_id)
            validation_util_obj = FieldValidationCycleUtil()
            old_data = {}
            old_data['jurisdiction_type'] = data['jurisdiction_type'] = af.jurisdiction.get_jurisdiction_type()              
            old_data['jurisdiction_id'] = data['jurisdiction_id'] = af.jurisdiction.id   
            old_data['jurisdiction'] = data['jurisdiction'] = af.jurisdiction 
            old_data['this_question'] = data['this_question'] = af.question
            
            category_name = 'VoteRequirement' 
            vote_info = validation_util_obj.get_jurisdiction_voting_info_by_category(category_name, af.jurisdiction, af.question.category, af.question)
            terminology = validation_util_obj.get_terminology(af.question)  
            #question_content = validation_util_obj.get_AHJ_question_data(request, update.jurisdiction, update.question, data)  
            question_content = validation_util_obj.get_authenticated_displayed_content(request, af.jurisdiction, af.question, vote_info, [af], terminology)
            for key in question_content.keys():
                data[key] = question_content.get(key) 
            
            data['answer'] = af
            #data['answer_text'] = aa.get_formatted_value(af.value, af.question)
            answer_text = requestProcessor.decode_jinga_template(request,'website/blocks/display_answer.html', data, '')
            data['answer_text'] = answer_text            
            data['jurisdiction'] = jurisdiction
            label = af.question.question
            if len(af.question.question) > 75:
                label = af.question.question[:78]+ '...'
            data['label'] = label
            
            data['commnets'] = comments
            
            others_afs = AnswerReference.objects.filter(jurisdiction = jurisdiction, question = af.question, approval_status='A').exclude(id = entity_id).order_by('-create_datetime')
            if len(others_afs) > 0 :
                old_answer = others_afs[0]
                if old_answer.id < af.id:
                    data['old_answer'] = old_answer
                    old_question_content = validation_util_obj.get_authenticated_displayed_content(request, old_answer.jurisdiction, old_answer.question, vote_info, [old_answer], terminology)
                    for key in old_question_content.keys():
                        old_data[key] = old_question_content.get(key)
                    #data['old_answer_text'] = aa.get_formatted_value(old_answer.value, old_answer.question)
                    old_answer_text = requestProcessor.decode_jinga_template(request,'website/blocks/display_answer.html', old_data, '')
                    data['old_answer_text'] = old_answer_text
                else:
                    data['old_answer'] = None
                    data['old_answer_text'] = ''
            else:
                data['old_answer'] = None
                data['old_answer_text'] = ''
  
            body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/jurisdiction_comment.html', data, '') 
            dajax.assign('#fancyboxformDiv','innerHTML', body)
            script = requestProcessor.decode_jinga_template(request,'website/jurisdictions/jurisdiction_comment.js', data, '')
            dajax.script(script)
            #script = requestProcessor.decode_jinga_template(request,'website/blocks/comments_list.js', data, '')
            #dajax.script(script)
            dajax.script('controller.showModalDialog("#fancyboxformDiv");')
        
        if ajax =='create_jurisdiction_comment':
            answer_id = requestProcessor.getParameter('answer_id')
            jid = requestProcessor.getParameter('jurisdiction_id')
            comment_type = 'JC'
            
            data['answer_id'] = answer_id
            data['jurisdiction_id'] = jid
            data['comment_type'] = comment_type
            data['parent_comment'] = ''
            body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/create_comment.html', data, '')
            script =  requestProcessor.decode_jinga_template(request,'website/jurisdictions/create_comment.js', data, '')
            dajax.assign('#secondDialogDiv','innerHTML', body) 
            dajax.script(script)
            dajax.script('controller.showSecondDialog("#secondDialogDiv");')
        
        if ajax =='comment_create_submit':
            entity_id = requestProcessor.getParameter('entity_id')
            entity_name = requestProcessor.getParameter('entity_name')
            jurisdiction_id = requestProcessor.getParameter('jurisdiction_id')
            comment_type = requestProcessor.getParameter('comment_type')
            comment_text = requestProcessor.getParameter('comment')
            parent_comment = requestProcessor.getParameter('parent_comment')
            try:
                jurisdiction = Jurisdiction.objects.get(id = jurisdiction_id)
            except:
                jurisdiction = None
                
            comment = Comment()
            comment.jurisdiction = jurisdiction
            comment.entity_name = entity_name
            comment.entity_id = entity_id
            comment.user = user
            comment.comment_type = comment_type
            comment.comment = comment_text
            if parent_comment != '':
                parent = Comment.objects.get(id = parent_comment)
                comment.parent_comment = parent
            comment.save()
            
            userviews = UserCommentView.objects.filter(user = user, jurisdiction = jurisdiction, entity_name = entity_name, entity_id = entity_id)
            userview = userviews[0]
            userview.last_comment = comment
            userview.comments_count = Comment.objects.filter(jurisdiction = jurisdiction, entity_name = entity_name, entity_id = entity_id).count()
            userview.view_datetime = datetime.datetime.now()
            userview.save()
            
            
            dajax.script('controller.closeSecondDialog();')
            dajax.script('controller.postRequest("/jurisdiction_comment/", {ajax: "open_jurisdiction_comment", jurisdiction_id:'+str(jurisdiction_id)+', entity_id: "'+str(entity_id)+'", entity_name: "'+str(entity_name)+'", comments_changed: "yes"});')

            data = {}
            answer = AnswerReference.objects.get(id=entity_id) 
            validation_util_obj = FieldValidationCycleUtil()                  
     
            question = answer.question
            data['this_question'] = question            
            
            question_content = validation_util_obj.get_AHJ_question_data(request, jurisdiction, question, data)  

            for key in question_content.keys():
                data[key] = question_content.get(key)
            
            body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content_authenticated.html', data, '')
       
            dajax.assign('#div_question_content_'+str(question.id),'innerHTML', body)
            script = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content.js', data, '')
            dajax.script(script)                
                
        if ajax =='reply_comment':
            cid = requestProcessor.getParameter('cid')
            comment = Comment.objects.get(id = cid)            
            data['comment'] = comment
            body = requestProcessor.decode_jinga_template(request,'website/blocks/reply_comment_form.html', data, '')
            script = requestProcessor.decode_jinga_template(request,'website/blocks/reply_comment_form.js', data, '')
            dajax.assign('#button-div-'+str(cid),'innerHTML', body) 
            dajax.script(script)
            
        
        if ajax == 'cancel_reply':
            cid = requestProcessor.getParameter('cid')
            body = '<a class="smallbutton" href="#" onClick="controller.postRequest(\'/jurisdiction_comment/\', {ajax: \'reply_comment\', cid: '+str(cid)+'});return false;">Reply</a><a class="smallbutton" href="#">Flag</a>'
            dajax.assign('#button-div-'+str(cid),'innerHTML', body) 
            
        if ajax == 'flag_comment':
            cid = requestProcessor.getParameter('cid')
            comment = Comment.objects.get(id = cid) 
            comment.approval_status = 'F'
            comment.save()
            
            af = AnswerReference.objects.get(id = comment.entity_id)
            to_mail = [django_settings.ADMIN_EMAIL_ADDRESS]
            data['comment'] = comment
            data['user'] = user
            data['question'] = af.question.question
            
            data['site_url'] = django_settings.SITE_URL
            data['requestProcessor'] = requestProcessor
            data['request'] = request
            send_email(data, to_mail)
            
            dajax.assign('#comment_'+str(cid), 'innerHTML', '<p>This comment had been flagged as inappropriate and is hidden pending review.</p>')
        
        if ajax == 'show_old_comments':
            entity_id = requestProcessor.getParameter('answer_id')
            entity_name = 'AnswerReference'
            jid = requestProcessor.getParameter('jurisdiction_id')
            try:
                jurisdiction = Jurisdiction.objects.get(id = jid)
            except:
                jurisdiction = None
            data['jurisdiction'] = jurisdiction
            comments = Comment.objects.filter(jurisdiction = jurisdiction, entity_name = entity_name, entity_id = entity_id, parent_comment__isnull = True).order_by('-create_datetime')
            
            userviews = UserCommentView.objects.filter(jurisdiction = jurisdiction, entity_name = entity_name, entity_id = entity_id, user = user)
            
            temp_comments = Comment.objects.filter(jurisdiction = jurisdiction, entity_name = entity_name, entity_id = entity_id).order_by('-create_datetime')
            last_comment = None
            if len(temp_comments) > 0 :
                last_comment = temp_comments[0]
            if len(userviews) > 0:
                userview = userviews[0]
                data['userview'] = userview
                data['userview_last_comment'] = userview.last_comment.id
                userview.comments_count = Comment.objects.filter(jurisdiction = jurisdiction, entity_name = entity_name, entity_id = entity_id).count()
                userview.last_comment = last_comment
                userview.view_datetime = datetime.datetime.now()
                userview.save()
            else:
                userview = None
                data['userview'] = userview
                data['userview_last_comment'] = 0
                userview = UserCommentView()
                userview.user = user
                userview.jurisdiction = jurisdiction
                userview.entity_name = entity_name
                userview.entity_id = entity_id
                userview.comments_count = Comment.objects.filter(jurisdiction = jurisdiction, entity_name = entity_name, entity_id = entity_id).count()
                userview.last_comment = last_comment
                userview.view_datetime = datetime.datetime.now()
                userview.save()
            data['commnets'] = comments
            
            body = requestProcessor.decode_jinga_template(request,'website/blocks/comments_list.html', data, '')
            dajax.assign('#old_list ul', 'innerHTML', body)
            dajax.assign('#show_commnet_div', 'innerHTML', '<a id="id_a_hide" href="#"><img src="/media/images/arrow_down.png" style="vertical-align:middle;" alt="Hide old comments"> Hide old comments </a>')
            script = requestProcessor.decode_jinga_template(request,'website/jurisdictions/jurisdiction_comment.js', data, '')
            dajax.script(script)
            
        return HttpResponse(dajax.json())
    return

def send_email(data, to_mail, subject='Flag Comment', template='flag_comment.html'): 
    #tp = django_get_template('website/emails/' + template)
    #c = Context(data)
    #body = tp.render(c)
    
    requestProcessor = data['requestProcessor']
    request = data['request']
    body = requestProcessor.decode_jinga_template(request, 'website/emails/' + template, data, '')

    from_mail = django_settings.DEFAULT_FROM_EMAIL

    msg = EmailMessage( subject, body, from_mail, to_mail)
    msg.content_subtype = "html"   
    msg.send()
    
def view_sc_AHJ(request, id):
    requestProcessor = HttpRequestProcessor(request)   
    jurisdiction = Jurisdiction.objects.get(id=id)  
             
    data = {}
    data['home'] = '/'     
    data['state'] = jurisdiction.state
    data['state_long_name'] = dict(US_STATES)[data['state']]  
    
    data['city'] = jurisdiction.city   
    data['jurisdiction_type'] = jurisdiction.get_jurisdiction_type()              
    data['jurisdiction_id'] = jurisdiction.id   
    data['jurisdiction'] = jurisdiction      
    
    data['jurisdiction_name_for_url'] = jurisdiction.get_name_for_url()
          
  
    data['jurisdiction'] = jurisdiction
    scfo_jurisdictions = Jurisdiction.objects.filter(parent=jurisdiction, jurisdiction_type__iexact='SCFO')
    data['scfo_jurisdictions'] = scfo_jurisdictions
    return requestProcessor.render_to_response(request,'website/jurisdictions/AHJ_sc.html', data, '')     
    
def view_unincorporated_AHJ(request, id):
    requestProcessor = HttpRequestProcessor(request)   
    jurisdiction = Jurisdiction.objects.get(id=id)  
             
    data = {}
    data['home'] = '/'     
    data['state'] = jurisdiction.state
    data['state_long_name'] = dict(US_STATES)[data['state']]  
    
    data['city'] = jurisdiction.city   
    data['jurisdiction_type'] = jurisdiction.get_jurisdiction_type()              
    data['jurisdiction_id'] = jurisdiction.id   
    data['jurisdiction'] = jurisdiction      
    
    data['jurisdiction_name_for_url'] = jurisdiction.get_name_for_url()
          
  
    data['jurisdiction'] = jurisdiction
    return requestProcessor.render_to_response(request,'website/jurisdictions/AHJ_unincorporated.html', data, '')     
    
    
def view_AHJ_by_name(request, name, category='general'):

        
    mathUtil = MathUtil()
    if mathUtil.is_number(name):
        jurisdiction = Jurisdiction.objects.get(id=name)
        if jurisdiction != None:
            return redirect('/jurisdiction/'+str(jurisdiction.get_name_for_url())+'/'+category)
    else:   
        name = name.replace('+', ' ')
        array_name = name.split('-')
        if len(array_name) == 2:
            name = str(BeautifulSoup(array_name[0],convertEntities=BeautifulSoup.HTML_ENTITIES))
            state = array_name[1]     
            jurisdictions = Jurisdiction.objects.filter(name__iexact=name, state__iexact=state)             
            
        elif len(array_name) == 3:
            name = str(BeautifulSoup(array_name[0],convertEntities=BeautifulSoup.HTML_ENTITIES))
            if array_name[1] == 'county' or array_name[1] == 'parish' or array_name[1] == 'burough':
                state = array_name[2]
                jurisdictions = Jurisdiction.objects.filter(name__iexact=name, state__iexact=state, jurisdiction_type__in=('CO','SC'))  #, jurisdiction_type__exact=jurisdiction_type
                      
        else:
            print 'not enough information to get the jur id'
            
    
        if len(jurisdictions) >= 1:
            jurisdiction = jurisdictions[0]
            id = jurisdiction.id
            
            if jurisdiction.jurisdiction_type == 'U':
                return view_unincorporated_AHJ(request, id)
            elif jurisdiction.jurisdiction_type == 'SC':
                return view_sc_AHJ(request, id)
            else:
                user = request.user
                ## the following to make sure the user has access to the view from the url
                if category != 'all_info':
                    question_categories = QuestionCategory.objects.filter(name__iexact=category, accepted=1)    
                    if len(question_categories) == 0: # not a question category, could be a view
                        if user.is_authenticated():
                            login_user = User.objects.get(id=user.id)
                            if login_user.is_staff or login_user.is_superuser or ('accessible_views' in request.session and category in request.session['accessible_views']):
                                pass  # logged in user, he is either a staff or superuser, or this user has access to the view per his organization membership
                            else:
                                return redirect('/jurisdiction/'+str(jurisdiction.get_name_for_url())+'/general')   # in the case of a non-question category, dump him at the general category       
                        else:
                            return redirect('/jurisdiction/'+str(jurisdiction.get_name_for_url())+'/general')   # in the case of a non-question category, dump him at the general category
                            
                return view_AHJ(request, id, category)
            
        else:
            print 'bad identification.  cannot find the jurisdiction'
            return redirect('/')
    
def view_AHJ(request, id, category='general'):
    
    requestProcessor = HttpRequestProcessor(request)        
    data = {}  
    dajax = Dajax()
    validation_util_obj = FieldValidationCycleUtil()  
    
    # to turn off the top nav bar
    data['nav'] = 'no'   
    data['current_nav'] = 'browse'    
    data['home'] = '/'       
    data['page'] = 'AHJ'
    data[category] = ' active'      # to set the active category in the left nav
    #question_category_objs = QuestionCategory.objects.filter(name__iexact=category)  
    #question_category_obj = question_category_objs[0]       # if this causes a problem, it's your fault in setting up the data.
    #data['category_obj'] = question_category_obj 
          
    jurisdiction = Jurisdiction.objects.get(id=id)
    datetime_util_obj = DatetimeHelper(jurisdiction.last_contributed)
    data['last_contributed_date'] = datetime_util_obj.showStateTimeFormat(jurisdiction.state)
        
    # to determine the last contributor's organization
    organization = None
    contributor = jurisdiction.last_contributed_by
    if contributor:
        organization_members = OrganizationMember.objects.filter(user=contributor, organization__status = 'A')
        if len(organization_members) > 0:
            organization = organization_members[0].organization
    '''       
    if organization != None: 
        data['last_contributed_by'] = organization.name
    elif contributor:
        data['last_contributed_by'] = contributor       # this is a user object
    else:
        data['last_contributed_by'] = ''
    '''
    data['last_contributed_by']  = contributor        
    data['state'] = jurisdiction.state
    data['state_long_name'] = dict(US_STATES)[data['state']]  
    
    data['city'] = jurisdiction.city   
    data['jurisdiction_type'] = jurisdiction.get_jurisdiction_type()              
    data['jurisdiction_id'] = jurisdiction.id   
    data['jurisdiction'] = jurisdiction      
    
    data['jurisdiction_name_for_url'] = jurisdiction.get_name_for_url()
    
    data['google_api_key'] = django_settings.GOOGLE_API_KEY     # may need to move this to where ever google map connection is initialized.
    
    layout = requestProcessor.getParameter('layout')
    q_layout = requestProcessor.getParameter('q')   
    
    if layout == None or layout == '':
        if q_layout != None and q_layout != '':
            layout = q_layout

    data['is_print'] = False
    if layout !=None and layout == 'print':
        data['is_print'] = True
        
    user = request.user
    data['user'] = user
    if user.is_authenticated() and jurisdiction != None:
        save_recent_search(user, jurisdiction)
        
    # ajax-related
    ajax = requestProcessor.getParameter('ajax')
    if (ajax != None):
        question_id = requestProcessor.getParameter('question_id')
        data['question_id'] = question_id
        jurisdiction_id = requestProcessor.getParameter('jurisdiction_id')
        data['jurisdiction_id'] = jurisdiction_id
        
        if jurisdiction_id != None:
            jurisdiction = Jurisdiction.objects.get(id=jurisdiction_id) 
            data['jurisdiction_type'] =  jurisdiction.get_jurisdiction_type()
            data['state'] = jurisdiction.state
            data['city'] = jurisdiction.city               
        else:
            data['jurisdiction_type'] = ''
            
            
        if question_id != None:
            question = Question.objects.get(id=question_id)
        else:
            question = None
                                    
        if (ajax == 'get_add_form'):  
            data['mode'] = 'add'
            
            data['form_field'] = {}
            form_field_data = validation_util_obj.get_form_field_data(jurisdiction, question)
            
            for key in form_field_data:
                data[key] = form_field_data[key]        

            data['default_values'] = {}
            if question.default_value != None and question.default_value != '':
                answer = json.loads(question.default_value) 
                for key in answer:
                    data[key] = str(answer[key])     
                    
            data['city'] =  jurisdiction.city
            data['state'] = jurisdiction.state           
        
            if 'question_template' in data and data['question_template'] != None and data['question_template'] != '':
                if form_field_data['question_id'] == 16:
                    data['fee_answer'] = answer
                    fee_info = validation_util_obj.process_fee_structure(answer)
                    for key in fee_info.keys():
                        data[key] = fee_info.get(key)    
                                     
                body = requestProcessor.decode_jinga_template(request,'website/form_fields/'+data['question_template'], data, '')    
            else:
                body = ''
 
            dajax.assign('#qa_'+str(question_id) + '_fields','innerHTML', body)
            
            #if 'js' in data and data['js'] != None and data['js'] != '':
            for js in data['js']:
                script ="var disable_pre_validation = false;" #set open pre validation by default, we can overwrite it under each field js file. 
                script += requestProcessor.decode_jinga_template(request, "website/form_fields/"+js, data, '')
                script +=";if ((!disable_pre_validation)&&!$('#form_"+question_id+"').checkValidWithNoError({formValidCallback:function(el){$('#save_"+question_id+"').removeAttr('disabled').removeClass('disabled');},formNotValidCallback:function(el){$('#save_"+question_id+"').attr('disabled','disabled').addClass('disabled');;}})){$('#save_"+question_id+"').attr('disabled','disabled').addClass('disabled');};"
                dajax.script(script)
                
            return HttpResponse(dajax.json()) 
        
        if (ajax == 'get_edit_form'):
            data['mode'] = 'edit'
            answer_id = requestProcessor.getParameter('answer_id')           
            answer_for_edit = AnswerReference.objects.get(id=answer_id)       

            data['values'] = {} 
            form_field_data = validation_util_obj.get_form_field_data(jurisdiction, question)
            for key in form_field_data:
                data[key] = form_field_data[key]    
                
            data['values'] = {}                
            answer = json.loads(answer_for_edit.value) 
            for key in answer:
                data[key] = answer[key]  
                
            #data['city'] =  jurisdiction.city
            #data['state'] = jurisdiction.state                                  
 
            data['answer_id'] = answer_id   
            print data['question_template']
            if 'question_template' in data and data['question_template'] != None and data['question_template'] != '':
                if form_field_data['question_id'] == 16:
                    data['fee_answer'] = answer
                    fee_info = validation_util_obj.process_fee_structure(answer)
                    for key in fee_info.keys():
                        data[key] = fee_info.get(key) 
                                    
                body = requestProcessor.decode_jinga_template(request,'website/form_fields/'+data['question_template'], data, '')    
            else:
                body = ''

            dajax.assign('#qa_'+str(answer_id) + '_edit_fields','innerHTML', body)

            #if 'js' in data and data['js'] != None and data['js'] != '':
            for js in data['js']:
                script = requestProcessor.decode_jinga_template(request, "website/form_fields/"+js, data, '')
                dajax.script(script)         
   
            return HttpResponse(dajax.json())         
                    
        if ajax == 'get_question_content_1st' or ajax == 'get_question_content':     
      
            data['this_question'] = question            
            
            question_content = validation_util_obj.get_AHJ_question_data(request, jurisdiction, question, data)  

            for key in question_content.keys():
                data[key] = question_content.get(key)
                        
            if request.user.is_authenticated():
                if data['has_no_answer'] == False:
                    body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content_authenticated.html', data, '')
                else:
                    body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content_authenticated_no_data.html', data, '')
            else:         
                body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content_unauthenticated.html', data, '')        

            dajax.assign('#div_question_content_'+str(question_id),'innerHTML', body)
            script = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content.js', data, '')
            dajax.script(script)
            
            if ajax == 'get_question_content':     
                # for google map
                if question.id == 4:
                    str_addr = validation_util_obj.get_addresses_for_map(jurisdiction)
                    dajax.script("load_google_map('"+str(str_addr)+"')")
                    
            dajax.script('$("#qa_'+str(question_id)+'_data .cancel_btn").tooltip({track: true});$("#qa_'+str(question_id)+'_data .edit_btn").tooltip({track: true});')      
              
            return HttpResponse(dajax.json())          
        
        if (ajax == 'suggestion_submit'):     
            answers = {} 
            field_prefix = 'field_'
            jurisdiction = Jurisdiction.objects.get(id=jurisdiction_id)    
            question = Question.objects.get(id=question_id)              
            answers = requestProcessor.get_form_field_values(field_prefix)

            for key, answer in answers.items():
                if answer == '':
                    del answers[key]
 
            process_answer(answers, question, jurisdiction, request.user) 
            
                        
            data['this_question'] = question            
            
            question_content = validation_util_obj.get_AHJ_question_data(request, jurisdiction, question, data)            
            
            for key in question_content.keys():
                data[key] = question_content.get(key)               
                            
            body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content_authenticated.html', data, '')
            dajax.assign('#div_question_content_'+str(question_id),'innerHTML', body)
            script = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content.js', data, '')
            dajax.script(script)
            
            # for google map
            if question.id == 4:
                str_addr = validation_util_obj.get_addresses_for_map(jurisdiction)
                dajax.script("load_google_map('"+str(str_addr)+"')")
                
            return HttpResponse(dajax.json())  
        
        if (ajax == 'suggestion_edit_submit'):     
            answers = {} 
            answer_id = requestProcessor.getParameter('answer_id')
            field_prefix = 'field_'
            jurisdiction = Jurisdiction.objects.get(id=jurisdiction_id)    
            question = Question.objects.get(id=question_id)              
            answers = requestProcessor.get_form_field_values(field_prefix)

            for key, answer in answers.items():
                if answer == '':
                    del answers[key]
                    
            process_answer(answers, question, jurisdiction, request.user, answer_id) 
            
            data['this_question'] = question            
            
            question_content = validation_util_obj.get_AHJ_question_data(request, jurisdiction, question, data)           
            
            for key in question_content.keys():
                data[key] = question_content.get(key)               
                            
            body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content_authenticated.html', data, '')
            dajax.assign('#div_question_content_'+str(question_id),'innerHTML', body)            
            script = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content.js', data, '')
            dajax.script(script)
          
            # for google map
            if question.id == 4:
                str_addr = validation_util_obj.get_addresses_for_map(jurisdiction)
                dajax.script("load_google_map('"+str(str_addr)+"')")
                
            return HttpResponse(dajax.json())  
        
        
        if (ajax == 'vote'):
            #data = {}
            requestProcessor = HttpRequestProcessor(request)
            dajax = Dajax()
                  
            ajax = requestProcessor.getParameter('ajax')
            if (ajax != None):
                if (ajax == 'vote'):
                    user = request.user
                    entity_id = requestProcessor.getParameter('entity_id') 
                    entity_name = requestProcessor.getParameter('entity_name') 
                    vote = requestProcessor.getParameter('vote')             
                    confirmed = requestProcessor.getParameter('confirmed')                     
                    if confirmed == None:
                        confirmed = 'not_yet'                            
                        
                    feedback = validation_util_obj.process_vote(user, vote, entity_name, entity_id, confirmed)
                  
                    if feedback == 'registered':
                        if entity_name == 'requirement':
                            answer = AnswerReference.objects.get(id=entity_id)     
                            #data['action'] = 'refresh_ahj_qa'
                            #body = validation_util_obj.get_question_answers_display_data(request, answer.jurisdiction, answer.question, data)    
                            #print 'here :: ' + str(answer.question_id)    
                            data['jurisdiction'] = answer.jurisdiction

                            question = answer.question                                
                            data['this_question'] = question            
                            
                            question_content = validation_util_obj.get_AHJ_question_data(request, data['jurisdiction'], question, data)  
                                
                            
                            for key in question_content.keys():
                                data[key] = question_content.get(key)                                  
                                            
                            body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content_authenticated.html', data, '')
                            dajax.assign('#div_question_content_'+str(question.id),'innerHTML', body)            
                            script = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content.js', data, '')
                            dajax.script(script)
                                                 
                            
                            dajax.script("show_hide_vote_confirmation('"+entity_id+"');")
                                        
                    elif feedback == 'registered_with_changed_status':
                        
                        if entity_name == 'requirement':
                            
                            answer = AnswerReference.objects.get(id=entity_id)   
                            
                            data['jurisdiction'] = answer.jurisdiction                            
                            #data['action'] = 'refresh_ahj_qa'  
                            #body = validation_util_obj.get_question_answers_display_data(request, answer.jurisdiction, answer.question, data)    
                            #print 'here :: ' + str(answer.question_id)    
                            #dajax.assign('#div_'+str(answer.question_id),'innerHTML', body)
                            
                            question = answer.question
                            data['this_question'] = question            
                            
                            question_content = validation_util_obj.get_AHJ_question_data(request, data['jurisdiction'], data['this_question'], data)  
                              
                            
                            for key in question_content.keys():
                                data[key] = question_content.get(key)                                             
                                            
                            body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content_authenticated.html', data, '')
                            dajax.assign('#div_question_content_'+str(question.id),'innerHTML', body)            
                            script = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content.js', data, '')
                            dajax.script(script)
                            
                            # for google map
                            if question.id == 4:
                                str_addr = validation_util_obj.get_addresses_for_map(data['jurisdiction'])
                                dajax.script("load_google_map('"+str(str_addr)+"')")                              
                            
                            terminology = question.terminology
                            if terminology == None or terminology == '':
                                terminology = 'value'                       
                              
                            if answer.approval_status == 'A':                          
                                dajax.script("controller.showMessage('"+str(terminology)+" approved.  Thanks for voting.', 'success');")  
                            elif answer.approval_status == 'R':
                                dajax.script("controller.showMessage('"+str(terminology)+" rejected. Thanks for voting.', 'success');") 
                            dajax.script("show_hide_vote_confirmation('"+entity_id+"');") 
                            
                            if category == 'all_info':
                                question_categories = QuestionCategory.objects.filter(accepted=1)
                                data['category'] = 'All categories'
                            else:
                                question_categories = QuestionCategory.objects.filter(name__iexact=category)
                                data['category'] = category
            
                            data['top_contributors'] = validation_util_obj.get_top_contributors(data['jurisdiction'], question_categories)  
                            body = requestProcessor.decode_jinga_template(request,'website/blocks/top_contributors.html', data, '')   
                            dajax.assign('#top_contributors','innerHTML', body)                                  


                    elif feedback == 'will_approve':
                        
                        # prompt confirmation
                        answer = AnswerReference.objects.get(id=entity_id)   
                        answers = AnswerReference.objects.filter(question=answer.question, jurisdiction=answer.jurisdiction)
                        if len(answers) > 1 and answer.question.has_multivalues == 0:
                            dajax.script("confirm_approved('yes');")
                        else:
                            dajax.script("confirm_approved('no');")
                    elif feedback == 'will_reject':
                        # prompt confirmation
                        dajax.script('confirm_rejected();')
                    #dajax.script("controller.showMessage('Your feedback has been sent and will be carefully reviewed.', 'success');")                 
                    
                    return HttpResponse(dajax.json())                     
        
        if (ajax == 'cancel_suggestion'):
            user = request.user
            entity_id = requestProcessor.getParameter('entity_id') 
            #entity_name = requestProcessor.getParameter('entity_name') 
            
            #if entity_name == 'requirement':
            answer = AnswerReference.objects.get(id=entity_id) 
            answer.approval_status = 'C'
            answer.status_datetime = datetime.datetime.now()
            answer.save()
                
            question = answer.question
            jurisdiction = answer.jurisdiction                           
            data['this_question'] = question            
            
            question_content = validation_util_obj.get_AHJ_question_data(request, jurisdiction, question, data)             
            
            for key in question_content.keys():
                data[key] = question_content.get(key)               
                            
            if data['has_no_answer'] == True:
                body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content_authenticated_no_data.html', data, '')            
            else:
                body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content_authenticated.html', data, '')
                
            dajax.assign('#div_question_content_'+str(question.id),'innerHTML', body)                     
            script = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content.js', data, '')
            dajax.script(script)
            
            # for google map
            if question.id == 4:
                str_addr = validation_util_obj.get_addresses_for_map(jurisdiction)
                dajax.script("load_google_map('"+str(str_addr)+"')")              
            
            return HttpResponse(dajax.json())  
        
        if (ajax == 'approve_suggestion'):

            user = request.user
            entity_id = requestProcessor.getParameter('entity_id') 

            answer = AnswerReference.objects.get(id=entity_id) 
            answer.approval_status = 'A'
            answer.status_datetime = datetime.datetime.now()
            answer.save()
   
            question = answer.question               
            jurisdiction = answer.jurisdiction  
            data['this_question'] = question            
            
            question_content = validation_util_obj.get_AHJ_question_data(request, jurisdiction, question, data)  
             
            
            for key in question_content.keys():
                data[key] = question_content.get(key)     
                            
            body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content_authenticated.html', data, '')
            dajax.assign('#div_question_content_'+str(question.id),'innerHTML', body)
            script = requestProcessor.decode_jinga_template(request,'website/jurisdictions/AHJ_question_content.js', data, '')
            dajax.script(script)
            
            '''
            question_categories = QuestionCategory.objects.filter(name__exact=question_category.name)
            data['top_contributors'] = validation_util_obj.get_top_contributors(answer.jurisdiction, question_categories)  
            body = requestProcessor.decode_jinga_template(request,'website/blocks/top_contributors.html', data, '')   
            dajax.assign('#top_contributors','innerHTML', body)            
            '''   
            
            if category == 'all_info':
                question_categories = QuestionCategory.objects.filter(accepted=1)
                data['category'] = 'All categories'
            else:
                question_categories = QuestionCategory.objects.filter(name__iexact=category)
                data['category'] = category


            data['jurisdiction'] = jurisdiction
            data['top_contributors'] = validation_util_obj.get_top_contributors(jurisdiction, question_categories)  
            body = requestProcessor.decode_jinga_template(request,'website/blocks/top_contributors.html', data, '')   
            dajax.assign('#top_contributors','innerHTML', body)                
            
            # for google map
            if question.id == 4:
                str_addr = validation_util_obj.get_addresses_for_map(jurisdiction)
                dajax.script("load_google_map('"+str(str_addr)+"')")   
                           
            return HttpResponse(dajax.json())         
                                                    
        if (ajax == 'validation_history'):
            caller = requestProcessor.getParameter('caller')
            entity_name = requestProcessor.getParameter('entity_name')              
            entity_id = requestProcessor.getParameter('entity_id')   
            data = validation_util_obj.get_validation_history(entity_name, entity_id)
            data['destination'] = requestProcessor.getParameter('destination')   
            
            if caller == None:
                params = 'zIndex: 8000'
            elif caller == 'dialog':
                params = 'zIndex: 12000'
                
            if data['destination'] == None:
                data['destination']  = ''
                            
            if data['destination'] == 'dialog':
                body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/validation_history_dialog.html', data, '') 
                dajax.assign('#fancyboxformDiv','innerHTML', body)       
                dajax.script('controller.showModalDialog("#fancyboxformDiv");')                
            else:
                body = requestProcessor.decode_jinga_template(request,'website/jurisdictions/validation_history.html', data, '')                 
                dajax.assign('#validation_history_div_'+entity_id,'innerHTML', body)
                #dajax.assign('.info_content','innerHTML', body)
                #dajax.script("controller.showInfo({target: '#validation_history_"+entity_id+"', "+params+"});")          
                        
            return HttpResponse(dajax.json())          
        
        return HttpResponse(dajax.json()) #don't return here yet, more ajax action at the end
            
            
              
    data['question_content'] = {}
    data['question_categories'] = {}    
    data['questions'] = {}
    data['custom_questions'] = {}
    template_obj = Template()
    jurisdiction_templates = template_obj.get_jurisdiction_question_templates(jurisdiction)

    if category == 'all_info':
        question_categories = QuestionCategory.objects.filter(accepted=1).order_by('display_order')
    else:
        question_categories = QuestionCategory.objects.filter(name__iexact=category, accepted=1)

    data['enable_custom_questions'] = True
    if len(question_categories) > 0:

        question_obj = Question()
                   
        question_category_objs = []
        for question_category in question_categories:
            question_category_obj = {}
            question_category_obj['question_category'] = question_category
            questions = Question.objects.filter(category=question_category, accepted=1, qtemplate__in=jurisdiction_templates).order_by('display_order')
            #question_category_obj['questions'] = question_obj.get_questions_by_category(templates, question_category.id)
            current_questions = []
            for question in questions:
                current_questions.append(question.id)
            question_category_obj['questions'] = questions
            question_category_obj['current_questions'] = current_questions
            question_category_objs.append(question_category_obj)
            
        data['question_categories'] = question_category_objs
    else: # no real question category => view
        question_category_objs = []
        views = View.objects.filter(name__iexact=category)  # we work with one view per ahj content, not like muliple categories in all_info
        if len(views) >= 0:
            view = views[0]

            vquestions = ViewQuestions.objects.filter(view = view).order_by('display_order')

                
            question_category_obj = {}   
            question_category_obj['question_category'] = view
            
            questions = []
            for vquestion in vquestions:
                questions.append(vquestion.question)            
                        
            current_questions = []
            for question in questions:
                current_questions.append(question.id)
            question_category_obj['questions'] = questions
            question_category_obj['current_questions'] = current_questions
            question_category_objs.append(question_category_obj)                
                
        data['question_categories'] = question_category_objs
        
        data['enable_custom_questions'] = False

        
               
    
    ''''
    question_obj = Question()
    for question_category_obj in question_categories:
        questions = question_obj.get_questions_by_category(templates, question_category_obj.id)   

        data['questions'][question_category_obj.id] = {}
        data['questions'][question_category_obj.id] = questions
    '''
    
    '''
        custom_questions = question_obj.get_custom_fields_by_jurisdiction_by_category(jurisdiction, question_category_obj.id)
        print 'custom_questions: ' + str(custom_questions)

        data['custom_questions'][question_category_obj.id] = {} #why is this here, when the next line erases it???
        data['custom_questions'][question_category_obj.id] = custom_questions        
    '''    
    if category == 'all_info':          
        question_categories = QuestionCategory.objects.filter(accepted=1)
        data['category'] = 'All categories'
        data['category_name'] = 'All categories'
    else:
        question_categories = QuestionCategory.objects.filter(name__iexact=category)
        data['category'] = category
        data['category_name'] = category.title().replace('_',' ')
        
    data['jurisdiction'] = jurisdiction    
    data['top_contributors'] = validation_util_obj.get_top_contributors(jurisdiction, question_categories)
    
    # to provide data for the google map
    data['category'] = category
    
    if category == 'general' or category == 'all_info':    
        data['str_address'] = validation_util_obj.get_addresses_for_map(jurisdiction)  
    else:
        data['str_address'] = ''
    

    # check this later                
    template = "website/jurisdictions/AHJ.html"

    if layout !=None and layout == 'print':
        template = 'website/jurisdictions/AHJ_print.html'

    data['layout'] = template  
    
    if data['is_print'] == True:
        data['page_format'] = 'print' 
    else:
        data['page_format'] = 'regular' 
    
    message_data = get_system_message(request) #get the message List
    data =  dict(data.items() + message_data.items())   #merge message list to data
    

    if 'accessible_views' in request.session:
        data['accessible_views'] = request.session['accessible_views']
    else:
        data['accessible_views'] = []
        
    return requestProcessor.render_to_response(request,'website/jurisdictions/AHJ_categories_questions.html', data, '') 
    '''
    if category == 'all_info':
        print "I am here 2"
        return requestProcessor.render_to_response(request,'website/jurisdictions/AHJ_categories_content.html', data, '') 
    else:
        print "I am here 3"
        return requestProcessor.render_to_response(request,'website/jurisdictions/AHJ_category_content.html', data, '')         
    '''
def process_answer(data, question, jurisdiction, user, answer_id=None):    
    answer = json.dumps(data)   # to convert to json

    if question:
        is_callout=0          

        validation_util_obj = FieldValidationCycleUtil() 
        arcf = validation_util_obj.save_answer(question, answer, jurisdiction, 'AddRequirement', user, is_callout, answer_id)
    else:
        print "no question '' has been set up" 

      
def save_recent_search(user, jurisdiction):
    try:
        user_search = UserSearch(user=user)
        user_search.entity_name = 'Jurisdiction'
        user_search.entity_id = jurisdiction.id
        user_search.label = jurisdiction.show_jurisdiction()
        user_search.save()
    except:
        pass
    