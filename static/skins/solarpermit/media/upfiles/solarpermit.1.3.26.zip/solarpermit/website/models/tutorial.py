import datetime
from django.db import models
from django.db.models import fields
from django.contrib.auth.models import User
from django.contrib.auth.models import Group
from django.contrib import admin
#from django_extensions.db.fields import UUIDField
from django.utils.encoding import smart_unicode
from django.conf import settings


class Tutorial(models.Model):
    identifier = models.CharField(max_length=64, blank=True, null=True, db_index=True)
    name = models.CharField(max_length=128, blank=True, null=True, db_index=True)
    description = models.TextField(blank=True, null=True)
    active = models.BooleanField(default=True) #show only if it is active
    start_datetime = models.DateTimeField(blank=True, null=True) #date to start showing, if None - show all time
    end_datetime = models.DateTimeField(blank=True, null=True) #date to end showing, if None - show all time
    def __unicode__(self):
        output = ''
        if self.name != None:
            output += self.name
        elif self.identifier != None:
            output += self.identifier
        return output
    class Meta:
        app_label = 'website'

class TutorialPage(models.Model):
    tutorial = models.ForeignKey(Tutorial, blank=True, null=True, db_index=True)
    selector = models.CharField(max_length=128, blank=True, null=True)
    tip = models.TextField(blank=True, null=True)
    display_order = models.SmallIntegerField(default=0)
    def __unicode__(self):
        output = ''
        if self.tip != None:
            output += self.tip
        return output
    class Meta:
        app_label = 'website'

class ActionTutorial(models.Model):
    action_identifier = models.CharField(max_length=64, blank=True, null=True, db_index=True)
    tutorial = models.ForeignKey(Tutorial, blank=True, null=True, db_index=True)
    def __unicode__(self):
        output = ''
        if self.action_identifier != None:
            output += self.action_identifier
        if self.tutorial != None:
            output += ' - ' + str(self.tutorial)
        return output
    class Meta:
        app_label = 'website'

class UserTutorialHistory(models.Model):
    user_email = models.EmailField(blank=True, null=True, db_index=True)
    tutorial = models.ForeignKey(Tutorial, blank=True, null=True, db_index=True)
    view_datetime = models.DateTimeField(blank=True, null=True)
    
    class Meta:
        app_label = 'website'
    
class UserTutorialPageHistory(models.Model):
    user_email = models.EmailField(blank=True, null=True, db_index=True)
    tutorial = models.ForeignKey(Tutorial, blank=True, null=True, db_index=True)
    page = models.ForeignKey(TutorialPage, blank=True, null=True, db_index=True)
    checked = models.BooleanField(default=False)
    
    class Meta:
        app_label = 'website'
