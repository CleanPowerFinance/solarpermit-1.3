from django.http import HttpResponseRedirect, HttpResponse, Http404

from django.template.loader import get_template
from django.template import Context, RequestContext
from website.utils.httpUtil import HttpRequestProcessor
from django.views.decorators import csrf
from dajax.core.Dajax import Dajax
from django.conf import settings 
from django.core.mail.message import EmailMessage
from django.shortcuts import render

from django.shortcuts import render_to_response
from website.utils.mathUtil import MathUtil
from website.utils.paginationUtil import PaginationUtil

from website.utils.messageUtil import MessageUtil

from website.models import UserDetail, OrganizationMember
from website.utils.messageUtil import MessageUtil,add_system_message,get_system_message

def get_info(request):
    data = {}
    requestProcessor = HttpRequestProcessor(request)
    dajax = Dajax()
          
    ajax = requestProcessor.getParameter('ajax')
    if (ajax != None):
        if (ajax == 'getting_started'):
            body = requestProcessor.decode_jinga_template(request,'website/info/getting_started.html', data, '')  
            dajax.assign('#fancyboxformDiv','innerHTML', body)  
            dajax.script('controller.showModalDialog("#fancyboxformDiv");')
            return HttpResponse(dajax.json())  
                
        if (ajax == 'about'):
            body = requestProcessor.decode_jinga_template(request,'website/blocks/about.html', data, '') 
            #dajax.assign('#main_content','innerHTML', body)    
            dajax.assign('#fancyboxformDiv','innerHTML', body)  
            dajax.script('controller.showModalDialog("#fancyboxformDiv");')
            return HttpResponse(dajax.json())
    
        if (ajax == 'privacy_policy'):
            body = requestProcessor.decode_jinga_template(request,'website/info/privacy_policy_modal.html', data, '') 
            #dajax.assign('#main_content','innerHTML', body)    
            dajax.assign('#fancyboxformDiv','innerHTML', body)  
            dajax.script('controller.showModalDialog("#fancyboxformDiv");')
            return HttpResponse(dajax.json())  
        
    
        if (ajax == 'terms_of_use'):
            body = requestProcessor.decode_jinga_template(request,'website/blocks/text_terms_of_use.html', data, '') 
            dajax.assign('#main_content','innerHTML', body)
            #dajax.assign('#fancyboxformDiv','innerHTML', body)  
            #dajax.script('controller.showModalDialog("#fancyboxformDiv");')    
            return HttpResponse(dajax.json())  
        
    
        if (ajax == 'disclaimer'):
            body = requestProcessor.decode_jinga_template(request,'website/info/disclaimer_modal.html', data, '') 
            #dajax.assign('#main_content','innerHTML', body)    
            dajax.assign('#fancyboxformDiv','innerHTML', body)  
            dajax.script('controller.showModalDialog("#fancyboxformDiv");')
            return HttpResponse(dajax.json()) 
        
        if (ajax == 'doe_grant'):
            body = requestProcessor.decode_jinga_template(request,'website/blocks/text_doe_grant.html', data, '') 
            #dajax.assign('#main_content','innerHTML', body)    
            dajax.assign('#fancyboxformDiv','innerHTML', body)  
            dajax.script('controller.showModalDialog("#fancyboxformDiv");')
            return HttpResponse(dajax.json()) 
        
        if (ajax == 'send_feedback'):
            data = {}     
            data['form_id'] = 'form_send_feedback'            
            
            data['feedback'] = requestProcessor.getParameter('feedback')    
            if data['feedback'] == None:
                data['feedback'] = ''                                                       
             
                body = requestProcessor.decode_jinga_template(request,'website/info/feedback.html', data, '') 
                dajax.assign('#fancyboxformDiv','innerHTML', body)                   
                dajax.script('controller.showModalDialog("#fancyboxformDiv");')

                return HttpResponse(dajax.json())  
            else:           
                data['email'] = settings.FEEDBACK_EMAIL
                data['user'] = request.user
                data['feedback'] = data['feedback'].lstrip('')
                orgmembers = OrganizationMember.objects.filter(user = data['user'], status = 'A')   
                user_orgs = ''
                if len(orgmembers) > 0:
                    for orgmember in orgmembers:
                        user_orgs += "," + orgmember.organization.name 
                        
                    user_orgs.lstrip(',')
                    
                data['user_orgs'] = user_orgs;
                user_details = UserDetail.objects.filter(user=data['user'])
                data['user_detail'] = user_details[0]
                email_feedback(data)
                dajax.script('jQuery.fancybox.close();')  
                dajax.script("controller.showMessage('Your feedback has been sent and will be carefully reviewed.', 'success');")                                                        
        
        return HttpResponse(dajax.json())              
    data['current_nav'] = 'home'
    return requestProcessor.render_to_response(request,'website/home.html', data, '')
    
def email_feedback(data): 
    subject = 'SolarPermit feedback from '+ data['user'].username
    tp = get_template('website/emails/feedback.html')
    c = Context(data)
    body = tp.render(c)
    #from_mail = data['user'].email
    from_mail = 'jack_smu@msn.com'
    to_mail = [data['email']]
    
    msg = EmailMessage( subject, body, from_mail, to_mail)
    msg.content_subtype = "html"   
    msg.send()

def news(request):
    data = {}
    data['current_nav'] = 'news'
    
    message_data = get_system_message(request) #get the message List
    data =  dict(data.items() + message_data.items())   #merge message list to data
    
    requestProcessor = HttpRequestProcessor(request)
    return requestProcessor.render_to_response(request,'website/info/news.html', data, '')

def about(request):
    data = {}
    data['current_nav'] = 'about'
    
    message_data = get_system_message(request) #get the message List
    data =  dict(data.items() + message_data.items())   #merge message list to data
    
    requestProcessor = HttpRequestProcessor(request)
    return requestProcessor.render_to_response(request,'website/info/about.html', data, '')

def getting_started_page(request):
    data = {}
    data['current_nav'] = ''
    
    message_data = get_system_message(request) #get the message List
    data =  dict(data.items() + message_data.items())   #merge message list to data
    
    requestProcessor = HttpRequestProcessor(request)
    return requestProcessor.render_to_response(request,'website/info/getting_started_page.html', data, '')

def privacy_policy(request):
    data = {}
    data['current_nav'] = 'home'
    
    requestProcessor = HttpRequestProcessor(request)
    return requestProcessor.render_to_response(request,'website/info/privacy_policy.html', data, '')

def grant_info(request):
    data = {}
    data['current_nav'] = 'home'
    
    requestProcessor = HttpRequestProcessor(request)
    return requestProcessor.render_to_response(request,'website/info/grant_info.html', data, '')

def information_accuracy_disclaimer(request):
    data = {}
    data['current_nav'] = 'home'
    
    requestProcessor = HttpRequestProcessor(request)
    return requestProcessor.render_to_response(request,'website/info/information_accuracy_disclaimer.html', data, '')

def terms_of_use(request):
    data = {}
    data['current_nav'] = 'home'
    
    requestProcessor = HttpRequestProcessor(request)
    return requestProcessor.render_to_response(request,'website/info/terms_of_use.html', data, '')

def page_404(request):
    data = {}
    
    requestProcessor = HttpRequestProcessor(request)
    #return HttpResponseNotFound('<h1>Page not found</h1>')
    print 8898999999999999999999999999
    return requestProcessor.render_to_response(request,'website/info/404.html', data, '')


