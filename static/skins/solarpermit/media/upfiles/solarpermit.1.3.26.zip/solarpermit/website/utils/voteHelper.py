#from server.website.models import JurisdictionContributor, Action, ActionCategory, AnswerReference, Question, OrganizationMember
from askbot.conf import settings as askbot_settings
from django.conf import settings as django_settings
from website.utils.mathUtil import MathUtil
from django.contrib.auth.models import User
from server.website.models import OrganizationMember
from server.website.models import ActionCategory, Action, Reaction, Comment

from website.models import AnswerReference, Question, QuestionCategory
from website.utils.contributionHelper import ContributionHelper

class VoteHelper():
    
    def get_voting_tally(self, category_name, entity_id):
        print "voting tally :: " + str(category_name)
        action_category = ActionCategory.objects.filter(name__iexact=category_name)
        positive_count = Action.objects.filter(category__in=action_category, entity_id__exact=entity_id, data__iexact="Vote: Up").count()
        negative_count = Action.objects.filter(category__in=action_category, entity_id__exact=entity_id, data__iexact="Vote: Down").count()
        print "positive count :: " + str(positive_count)
        total_count = Action.objects.filter(category__in=action_category, entity_id__exact=entity_id).count()
        print "neg_count :: " + str(negative_count)
        print total_count
        if total_count > 0:
            positive_percentage = float(positive_count) / float(total_count) * float(100)
        else:
            positive_percentage = 0.0
         
        mathUtil_obj = MathUtil()
        positive_percentage = mathUtil_obj.round(positive_percentage) 
        
        vote_info = {}
        vote_info['total_votes'] = total_count
        vote_info['total_pos_votes'] = positive_count
        vote_info['total_neg_vote'] = negative_count
        vote_info['percent_pos'] =  positive_percentage  
        #print positive_percentage
        return vote_info

    def vote(self, eid, vote, user_id, entity_name, jurisdiction_id):
        print "entity_name :: " + str(entity_name)        
        if entity_name == 'Requirement':
            action_category_name = 'VoteRequirement'
        elif entity_name == 'Callout':
            action_category_name = 'VoteCallout'                  
        elif entity_name == 'Comment':
            action_category_name = 'VoteComment'  
        elif entity_name == 'Info':
            action_category_name = 'VoteInfo'
        
        print "action_category_name :: " + str(action_category_name)
        print "user_id >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> :: " + str(user_id)
        user_obj = User.objects.get(pk=user_id)
        
        action_category = ActionCategory.objects.filter(name__iexact=action_category_name)  
  
        action_objs = Action.objects.filter(category__exact=action_category[0], entity_id = eid, user__exact=user_obj)

        if action_objs:
            print "updating old vote"           
            action_obj = action_objs[0]
            action_data = "Vote: " + vote.title()
            action_obj.data = str(action_data)
            action_obj.save()
        else:
            print "new vote" 
            contributionHelper = ContributionHelper()           
            action_obj = contributionHelper.save_action(action_category_name, vote, eid, entity_name, user_id, jurisdiction_id)
            
        print "vote logged"
        print "before rate - action_category_name :: " + str(action_category_name)
        self.rate(action_category_name, entity_name, eid, action_obj, user_id, jurisdiction_id)
        
        return action_obj
    
    def rate(self, action_category_name, entity_name, eid, action_obj, user_id, jurisdiction_id):
        print "in rate - action_category_name :: " + str(action_category_name)
        if action_category_name == 'VoteRequirement' or action_category_name == 'VoteCallout'  or action_category_name == 'VoteInfo':
            vote_info = self.get_voting_tally(action_category_name, eid)
            rating = vote_info['total_pos_votes'] - vote_info['total_neg_vote']
            print "rating = " + str(rating)
            answer_reference_obj = AnswerReference.objects.get(id=eid)
            current_rating_status = answer_reference_obj.rating_status        
            question = Question.objects.get(id=answer_reference_obj.question_id)
            category = QuestionCategory.objects.get(id=question.category_id)
            entity_category_id = category.id                  
            
            print 'before setting rating status'
            print 'MIN_RATING_TO_CONFIRMM :: ' + str(askbot_settings.MIN_RATING_TO_CONFIRM)
            print 'NEG_RATING_TO_HIDEE :: ' + str(askbot_settings.NEG_RATING_TO_HIDE)
            print 'MIN_REP_TO_VOTE_UPP :: ' + str(askbot_settings.MIN_REP_TO_VOTE_UP)
            print 'MIN_REP_TO_VOTE_DOWNN :: ' + str(askbot_settings.MIN_REP_TO_VOTE_DOWN)               
            contributionHelper = ContributionHelper()  
            if rating >= askbot_settings.MIN_RATING_TO_CONFIRM:
                answer_reference_obj.rating_status = 'C'    #status confirmed
                if current_rating_status != 'C':
                    contributionHelper.save_reaction(entity_name, eid, action_obj, 'C',  entity_category_id, user_id, jurisdiction_id )             
            if rating <= askbot_settings.NEG_RATING_TO_HIDE:
                answer_reference_obj.rating_status = 'D'    #status disputed
                if current_rating_status != 'D':
                    contributionHelper.save_reaction(entity_name, eid, action_obj, 'D',  entity_category_id, user_id, jurisdiction_id )              
            if rating < askbot_settings.MIN_RATING_TO_CONFIRM and rating > askbot_settings.NEG_RATING_TO_HIDE:
                answer_reference_obj.rating_status = 'U'
                if current_rating_status != 'U':
                    contributionHelper.save_reaction(entity_name, eid, action_obj, 'U',  entity_category_id, user_id, jurisdiction_id )   
                                
            answer_reference_obj.rating = rating
            answer_reference_obj.save()
            print "rating status :: " + answer_reference_obj.rating_status
            
        elif action_category_name == 'VoteComment':
            print "rate_on_comment"
            category_name = 'VoteComment'
            vote_info = self.get_voting_tally(category_name, eid)
            print "vote_info :: " 
            print vote_info
            rating = vote_info['total_pos_votes'] - vote_info['total_neg_vote']
            print "rating = " + str(rating)
            comment_obj = Comment.objects.get(id=eid)
            print comment_obj
            if (rating < 0): rating = 0
            comment_obj.rating = rating
            comment_obj.save()
            
        return rating          

    def check_can_vote_up(self, user, category_name='', entity_id=0):
        print 'check_can_vote_up'
        if user.is_authenticated():   
            user_rep = user.reputation
            print 'JJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJJ'
            print user_rep
            min_rep_to_vote_up = askbot_settings.MIN_REP_TO_VOTE_UP
            print min_rep_to_vote_up
            if user_rep >= min_rep_to_vote_up:
                print 'get last vote'
                last_vote_obj = self.get_user_last_vote_on_an_item(category_name, entity_id, user.id)
                print last_vote_obj
                if last_vote_obj: 
                    print "last vote :: " + str(last_vote_obj[0].data)
                    if last_vote_obj[0].data == 'Vote: Down':            
                        return 1
                else:
                    return 1
            
        return 0    
    
    def check_can_vote_down(self, user, category_name='', entity_id=0):
        print 'check_can_vote_down'
        if user.is_authenticated():   
            user_rep = user.reputation
            print user_rep
            min_rep_to_vote_down = askbot_settings.MIN_REP_TO_VOTE_DOWN
            print min_rep_to_vote_down
            if user_rep >= min_rep_to_vote_down:
                print 'get last vote'
                last_vote_obj = self.get_user_last_vote_on_an_item(category_name, entity_id, user.id)
                print last_vote_obj
                if last_vote_obj: 
                    if last_vote_obj[0].data == 'Vote: Up':            
                        return 1
                else:
                    return 1
            
        return 0
    
    def check_can_vote(self, user, category_name):
        can_vote_up = {}
        can_vote_down = {}    
        if user.is_authenticated():   
            user_rep = user.reputation
            min_rep_to_vote_up = askbot_settings.MIN_REP_TO_VOTE_UP
            min_rep_to_vote_down = askbot_settings.MIN_REP_TO_VOTE_DOWN
            
            last_vote_objs = self.get_user_last_vote_on_category_items(category_name, user.id)
            for vote_obj in last_vote_objs:
                if user_rep >= min_rep_to_vote_up and vote_obj.data == 'Vote: Down':
                    can_vote_up[vote_obj.entity_id] = 1
                else:
                    can_vote_up[vote_obj.entity_id] = 0
                
                if user_rep >= min_rep_to_vote_down and vote_obj.data == 'Vote: Up':
                    can_vote_down[vote_obj.entity_id] = 1
                else:
                    can_vote_down[vote_obj.entity_id] = 0
            
        return (can_vote_up, can_vote_down)       
    
    def get_user_last_vote_on_an_item(self, category_name, entity_id, user_id):
        user_obj = User.objects.get(pk=user_id)   
        print user_obj
        action_category = ActionCategory.objects.filter(name__iexact=category_name)
        print action_category
        vote_objs = Action.objects.filter(category__exact=action_category, entity_id__exact=entity_id, user__exact=user_obj).order_by('action_datetime')

        return vote_objs;
    
    def get_user_last_vote_on_category_items(self, category_name, user_id):
        user_obj = User.objects.get(pk=user_id)   
        action_category = ActionCategory.objects.filter(name__iexact=category_name)
        vote_objs = Action.objects.filter(category__exact=action_category, user__exact=user_obj)
        
        return vote_objs      
   

