

function validate_form_to_enable_submit_button(form_id)
{
    submit_button_id = form_id+'_submit_button';
    if (validate_form(form_id))
    {

        document.getElementById(submit_button_id).disabled = false;
        document.getElementById(submit_button_id).title = get_submit_button_title(submit_button_id, 'abled');
        document.getElementById(submit_button_id).style.opacity = 1;
        document.getElementById(submit_button_id).style.filter = 'alpha(opacity=100)';        
        document.getElementById(submit_button_id).className = 'mainbutton';
   	}
    else
    {
        document.getElementById(submit_button_id).disabled = true;
        document.getElementById(submit_button_id).title = get_submit_button_title(submit_button_id, 'disabled');   
        document.getElementById(submit_button_id).style.opacity = 0.5;
        document.getElementById(submit_button_id).style.filter = 'alpha(opacity=50)';
        document.getElementById(submit_button_id).className = 'mainbutton disabled';
   	}
   	
   	return false;
}


function validate_form_before_submit(form_id)
{
    if (validate_form(form_id))
        return true;
    else
        return false;
}

function validate_form(form_id)
{   
	if (form_id == 'form_change_password')
	    return validate_form_change_password();
   
	if (form_id == 'form_create_account')
	    return validate_form_create_account(); 
	    
	if (form_id == 'form_create_org')
	    return validate_form_create_org(); 	    
	    
	if (form_id == 'form_user_profile')
	    return validate_form_user_profile(); 
	    
	if (form_id == 'form_trouble_signing_in')
	    return validate_form_trouble_signing_in(); 	
	    
	if (form_id == 'form_reset_password')
	    return validate_form_reset_password(); 			    	    	 

	if (form_id == 'form_send_feedback')
	    return validate_form_send_feedback(); 	
	    	    	    
    return false;
}

function get_submit_button_title(submit_button_id, disabled)
{
	title = Array();
	title['form_change_password_submit_button'] = Array();
	title['form_change_password_submit_button']['disabled'] = "Complete the form above to change the password.";
	title['form_change_password_submit_button']['abled'] = "Change password.";
	title['form_create_account_submit_button'] = Array();
	title['form_create_account_submit_button']['disabled'] = "Complete the form above to create your new account";
	title['form_create_account_submit_button']['abled'] = "Create your new account.";	
	title['form_create_org_submit_button'] = Array();
	title['form_create_org_submit_button']['disabled'] = "Complete the form above to create your new organization";
	title['form_create_org_submit_button']['abled'] = "Create your new organization.";	
	title['form_trouble_signing_in_submit_button'] = Array();	
	title['form_trouble_signing_in_submit_button']['disabled'] = "Complete the form above to receive instruction on resetting the password";
	title['form_trouble_signing_in_submit_button']['abled'] = "Submit";	
	title['form_reset_password_submit_button'] = Array();	
	title['form_reset_password_submit_button']['disabled'] = "Complete the form above to reset your password";
	title['form_reset_password_submit_button']['abled'] = "Submit";		
	title['form_send_feedback_submit_button'] = Array();			
	title['form_send_feedback_submit_button']['disabled'] = "Complete the form above to provide feedback";
	title['form_send_feedback_submit_button']['abled'] = "Send your feedback";		
	
	return title[submit_button_id][disabled];
}

function validateEmail(email) {
  var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
  if( !emailReg.test( email ) ) {
    return false;
  } else {
    return true;
  }
}

/********* Send Feedback - start *********/

function check_form_send_feedback_field_feedback(obj, message_div, form_id)
{   
    if( obj.value == '')
        document.getElementById(message_div).innerHTML="Please provide your feedback.";
    else
        document.getElementById(message_div).innerHTML='';
    
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function validate_form_send_feedback()
{   
  	if (document.getElementById('form_send_feedback_field_feedback').value == '') 
    	return false;

    return true;
}

/********* Send Feedback - End ***********/

/********* Trouble Reset Password - start *********/
function check_form_reset_password_field_password(obj, message_div, verify_password_id, form_id)
{   
    if(obj.value.length < 8)
        document.getElementById(message_div).innerHTML="Your password must be a minimum of 8 characters.";
    else
    {
        document.getElementById(message_div).innerHTML='';
        document.getElementById(verify_password_id).disabled = false;
    }
        
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function check_form_reset_password_field_verify_password(obj, message_div, password_id, form_id)
{   
    passwordObj = document.getElementById(password_id);
    if(obj.value != passwordObj.value)
        document.getElementById(message_div).innerHTML="The password fields must be exactly the same.";
    else
        document.getElementById(message_div).innerHTML='';
        
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function validate_form_reset_password()
{   
  	if (document.getElementById('form_reset_password_field_password').value.length < 8) 
    	return false;
   	else
      	if (document.getElementById('form_reset_password_field_password').value != document.getElementById('form_reset_password_field_verify_password').value) 
      		return false;    

    return true;
}

/********* Trouble Reset Password - End ***********/

/********* Trouble Signing In - start *********/
function check_form_trouble_signing_in_field_email(obj, message_div, form_id)
{   
    if( obj.value === '' || !validateEmail(obj.value))
        document.getElementById(message_div).innerHTML="You must enter a valid email address. For example, myname@mycompany.com.";
    else
        document.getElementById(message_div).innerHTML='';
        
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function validate_form_trouble_signing_in()
{   
    if (document.getElementById('form_trouble_signing_in_field_email').value == '') 
        return false;
    else
        if (!validateEmail(document.getElementById('form_trouble_signing_in_field_email').value)) return false;

    return true;
}


/********* Trouble Signing In - End ***********/

/********* Change Password - start ************/

function check_form_change_password_field_password(obj, message_div, verify_password_id, form_id)
{   
    if(obj.value.length < 8)
        document.getElementById(message_div).innerHTML="your password must be a minimum of 8 characters.";
    else
    {
        document.getElementById(message_div).innerHTML='';
        document.getElementById(verify_password_id).disabled = false;
    }
        
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function check_form_change_password_field_verify_password(obj, message_div, password_id, form_id)
{   
    passwordObj = document.getElementById(password_id);
    if(obj.value != passwordObj.value)
        document.getElementById(message_div).innerHTML="The password fields must be exactly the same.";
    else
        document.getElementById(message_div).innerHTML='';
        
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function validate_form_change_password()
{   
  	if (document.getElementById('form_change_password_field_password').value.length < 8) 
    	return false;
   	else
      	if (document.getElementById('form_change_password_field_password').value != document.getElementById('form_change_password_field_verify_password').value) 
      		return false;    

    return true;
}

/********* Change Password - end ************/


/********* Create Account - start ***********/

/* Using jquery.validate.js instead
function check_form_create_account_field_username(obj, message_div, form_id)
{   
    if( obj.value === '')
        document.getElementById(message_div).innerHTML="Username is required.";
    else
        document.getElementById(message_div).innerHTML='';
    
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function check_form_create_account_field_email(obj, message_div, form_id)
{   
    if( obj.value === '' || !validateEmail(obj.value))
        document.getElementById(message_div).innerHTML="You must enter a valid email address. For example, myname@mycompany.com.";
    else
        document.getElementById(message_div).innerHTML='';
        
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function check_form_create_account_field_password(obj, message_div, verify_password_id, form_id)
{   
    if(obj.value.length < 8)
        document.getElementById(message_div).innerHTML="your password must be a minimum of 8 characters.";
    else
    {
        document.getElementById(message_div).innerHTML='';
        document.getElementById(verify_password_id).disabled = false;
    }
        
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function check_form_create_account_field_verify_password(obj, message_div, password_id, form_id)
{   
    passwordObj = document.getElementById(password_id);
    if(obj.value != passwordObj.value)
        document.getElementById(message_div).innerHTML="The password fields must be exactly the same.";
    else
        document.getElementById(message_div).innerHTML='';
        
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function validate_form_create_account()
{   
    if (document.getElementById('form_create_account_field_username').value == '') return false;
    if (document.getElementById('form_create_account_field_email').value == '') 
        return false;
    else
        if (!validateEmail(document.getElementById('form_create_account_field_email').value)) return false;
    if (document.getElementById('form_create_account_field_password').value.length < 8) 
        return false;
    else
        if (document.getElementById('form_create_account_field_password').value != document.getElementById('form_create_account_field_verify_password').value) return false;    
    if (document.getElementById('form_create_account_field_accept_tou').checked == false) return false;
    
    return true;
}

*/
/********* Create Account - end ***********/

/********* User Profile - start ***********/


function check_form_user_profile_field_username(obj, message_div, form_id)
{   
    if( obj.value === '')
        document.getElementById(message_div).innerHTML="Username is required.";
    else
        document.getElementById(message_div).innerHTML='';
    
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function check_form_user_profile_field_email(obj, message_div, form_id)
{   
    if( obj.value === '' || !validateEmail(obj.value))
        document.getElementById(message_div).innerHTML="You must enter a valid email address. For example, myname@mycompany.com.";
    else
        document.getElementById(message_div).innerHTML='';
        
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function check_form_user_profile_field_password(obj, message_div, verify_password_id, form_id)
{   
    if(obj.value.length < 8)
        document.getElementById(message_div).innerHTML="your password must be a minimum of 8 characters.";
    else
    {
        document.getElementById(message_div).innerHTML='';
        document.getElementById(verify_password_id).disabled = false;
    }
        
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function check_form_user_profile_field_verify_password(obj, message_div, password_id, form_id)
{   
    passwordObj = document.getElementById(password_id);
    if(obj.value != passwordObj.value)
        document.getElementById(message_div).innerHTML="The password fields must be exactly the same.";
    else
        document.getElementById(message_div).innerHTML='';
        
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function validate_form_user_profile()
{   
    if (document.getElementById('form_user_profile_field_username').value == '') return false;
    if (document.getElementById('form_user_profile_field_email').value == '') 
        return false;
    else
        if (!validateEmail(document.getElementById('form_user_profile_field_email').value)) return false;
    /*
    if (document.getElementById('form_user_profile_field_password').value.length < 8) 
        return false;
    else
        if (document.getElementById('form_user_profile_field_password').value != document.getElementById('form_user_profile_field_verify_password').value) return false;    
	*/
    return true;
}


/********* User Profile - end ***********/


/********* Create Organization - start ***********/


function check_form_create_org_field_name(obj, message_div, form_id)
{   
    if( obj.value === '')
        document.getElementById(message_div).innerHTML="Organization name is required.";
    else
        document.getElementById(message_div).innerHTML='';
    
     validate_form_to_enable_submit_button(form_id);

    return false;
}

function check_form_create_org_field_logo(obj, message_div, form_id)
{   
/*
    if( obj.value === '' || !validateEmail(obj.value))
        document.getElementById(message_div).innerHTML="You must enter a valid email address. For example, myname@mycompany.com.";
    else
        document.getElementById(message_div).innerHTML='';
        
     validate_form_to_enable_submit_button(form_id);

    return false;
*/
}

function check_form_create_org_field_website(obj, message_div, form_id)
{   
/*
    if(obj.value.length < 8)
        document.getElementById(message_div).innerHTML="your password must be a minimum of 8 characters.";
    else
    {
        document.getElementById(message_div).innerHTML='';
        document.getElementById(verify_password_id).disabled = false;
    }
        
     validate_form_to_enable_submit_button(form_id);

    return false;
*/
}

function validate_form_create_org()
{   
    if (document.getElementById('form_create_org_field_name').value == '') return false;
/*
    if (document.getElementById('form_create_account_field_email').value == '') 
        return false;
    else
        if (!validateEmail(document.getElementById('form_create_account_field_email').value)) return false;
    if (document.getElementById('form_create_account_field_password').value.length < 8) 
        return false;
    else
        if (document.getElementById('form_create_account_field_password').value != document.getElementById('form_create_account_field_verify_password').value) return false;    
    if (document.getElementById('form_create_account_field_accept_tou').checked == false) return false;
*/    
    return true;
}


/********* Create Organization - end ***********/