
$( "#tabs" ).tabs();
$("#wp_cancel_btn").click(function () {$.fancybox.close();});