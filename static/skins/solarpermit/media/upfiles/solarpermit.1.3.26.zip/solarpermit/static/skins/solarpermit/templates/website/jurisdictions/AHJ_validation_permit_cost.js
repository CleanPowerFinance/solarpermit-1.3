//for IE8 fix, prevent form with ajax from submitting normally after validation
/*
$('input[name="ajax"]').closest('form').each(function () {
	$(this).submit( function( event ) {
		event.preventDefault();
	});
});
*/


var available_components = Array('flat_rate', 'percentage_of_total_system_cost', 'fee_per_component', 'jurisdiction_cost_recovery');
var selected_components = Array('');
var current_component = 'flat_rate';
var current_component_num = 0;
function init_permit_cost()
{
    selected_components = Array('');
    current_component = 'flat_rate';    
    current_component_num = 0;    
    return false;
}

$('#select_formula_component_0').change(function() {
	$target = $(event.target);
	//alert($target.val());
	show_cost_formula_component($target.val(), 0);
});

$('#select_formula_component_1').change(function() {
	$target = $(event.target);
	//alert($target.val());	
	show_cost_formula_component($target.val(), 1);
});

$('#select_formula_component_2').change(function() {
	$target = $(event.target);
	//alert($target.val());	
	show_cost_formula_component($target.val(), 2);
});

$('#select_formula_component_3').change(function() {
	$target = $(event.target);
	//alert($target.val());	
	show_cost_formula_component($target.val(), 3);
});

function show_cost_formula_component(selected_component, component_num)
{   
    //alert('current_component :: ' + current_component); 
    //alert('current_component_num :: ' + current_component_num);     
    //alert('selected component :: ' + selected_component); 
    //alert('component_num :: ' + component_num);     
    document.getElementById('formula_component_'+component_num).innerHTML = '';
    replacement_field = document.getElementById('formula_component_'+selected_component+'_copy').innerHTML;
    replacement_field = replacement_field.replace(/xxx/g, 'field');
    replacement_field = replacement_field.replace(/yyy_/g, '');
    document.getElementById('formula_component_'+component_num).innerHTML = replacement_field;
    current_component = selected_component;

    //alert('current_component :: ' + current_component); 
    //alert('current_component_num :: ' + current_component_num);  
        
    return false;         
}

$('#add_another_cost_btn').click(function() {
	$target = $(event.target);
	//alert($target.val());	
	add_another_cost_component();
});

function add_another_cost_component()
{
    //alert('current_component :: ' + current_component); 
    //alert('current_component_num :: ' + current_component_num); 
    selected_components.push(current_component);   
 

        
    /* show the next group */
    next_component = ''
    for (var x=0; x < available_components.length; x++)
    {
        found = false;
        for (var y=0; y < selected_components.length; y++)
        {
            if (available_components[x] == selected_components[y])
            {
                found = true;
                break;
            }
        }
     
        if (found == false)
        {
            next_component = available_components[x];
            break;
        }
    }
    //alert ('next_component :: ' + next_component);
 

  
    current_component = next_component;

        
    document.getElementById('formula_component_selection_'+current_component_num).style.display="none"; 
    current_component_num = current_component_num + 1;    
    //alert('new_current_component_num :: ' + current_component_num); 
    document.getElementById('formula_component_selection_'+current_component_num).style.display="block";   
    document.getElementById('formula_component_'+current_component_num).style.display="block"; 
    replacement_field = document.getElementById('formula_component_'+current_component+'_copy').innerHTML;  
    replacement_field = replacement_field.replace(/xxx/g, 'field');
    replacement_field = replacement_field.replace(/yyy_/g, '');
    document.getElementById('formula_component_'+current_component_num).innerHTML = replacement_field;
    
    //alert('current_component :: ' + current_component); 
    //alert('current_component_num :: ' + current_component_num);     
    
    if (available_components.length == selected_components.length)
    	 $('#add_another_cost_btn').hide();
    	
    return false;
}
 
$('#save_{{question_id}}').click(function(event) {
	$target = $(event.target);
	//alert('add');
	if ($('#fee_per_inverter').is(":visible"))
	{	//alert('visible');
	    if (($('#fee_per_inverter').val() != '' && $('#fee_per_inverter').val() != '0') || ($('#fee_per_module').val() != ''  && $('#fee_per_module').val() != '0') || ($('#fee_per_major_components').val() != ''  && $('#fee_per_major_components').val() != '0') ) 
	    {
			$('#fee_per_inverter').removeClass('required');
			$('#fee_per_module').removeClass('required');
			$('#fee_per_major_components').removeClass('required');								
		}
		else
		{
			//alert('test');
			$('#fee_per_component_error').html('At least one field is required');
		}
	
		if ($('#form_{{question_id}}').validate().form()) {
			return true;
		}
		else
			return false;
	}
	else
		return true;
});

$('#save_edit_{{answer_id}}').click(function(event) {
	$target = $(event.target);
	//alert('edit');
	//alert($('#fee_per_inverter').val());
	if ($('#fee_per_inverter').is(":visible"))
	{	//alert('visible');
		//alert($('#fee_per_inverter').val());
	    if (($('#fee_per_inverter').val() != '' && $('#fee_per_inverter').val() != '0') || ($('#fee_per_module').val() != ''  && $('#fee_per_module').val() != '0') || ($('#fee_per_major_components').val() != ''  && $('#fee_per_major_components').val() != '0') ) 
	    {
	    	//alert('at one value was entered');
			$('#fee_per_inverter').removeClass('required');
			$('#fee_per_module').removeClass('required');
			$('#fee_per_major_components').removeClass('required');								
		}
		else
		{
			$('#fee_per_component_error').html('At least one field is required');
		}		
	
		if ($('#form_edit_{{answer_id}}').validate().form()) {
			return true;
		}
		else
			return false;
	}
	else
		return true;
});

$('#form_{{question_id}}').validate({
	messages: {
		fee_per_inverter: 'At least one field is required',
		fee_per_module: 'At least one field is required',
		fee_per_major_components: 'At least one field is required'
	}
});

$('#form_edit_{{answer_id}}').validate({
	messages: {
		fee_per_inverter: 'At least one field is required',
		fee_per_module: 'At least one field is required',
		fee_per_major_components: 'At least one field is required'
	}
});
