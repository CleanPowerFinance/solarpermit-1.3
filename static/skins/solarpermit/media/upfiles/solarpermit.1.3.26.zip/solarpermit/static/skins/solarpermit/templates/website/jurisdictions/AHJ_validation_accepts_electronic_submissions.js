//for IE8 fix, prevent form with ajax from submitting normally after validation
/*
$('input[name="ajax"]').closest('form').each(function () {
	$(this).submit( function( event ) {
		event.preventDefault();
	});
});
*/

$('#radio_url_for_online_submissions').click(function(event) {
	$('#radio_url_for_online_submissions').attr('checked', true);
	$('#radio_email_address_for_online_submissions').removeAttr('checked');
	
	$('#email_address_for_online_submissions').removeClass('required');
	$('#email_address_for_online_submissions').attr('disabled','disabled');
	
	$('#url_for_online_submissions').removeAttr('disabled');		
	$('#url_for_online_submissions').addClass('required url');
	$('#url_for_online_submissions').focus();

    return false;
});

$('#radio_email_address_for_online_submissions').click(function(event) {
	$('#radio_url_for_online_submissions').removeAttr('checked');
	$('#radio_email_address_for_online_submissions').attr('checked', true);
	
	$('#url_for_online_submissions').removeClass('required');
	$('#url_for_online_submissions').attr('disabled','disabled');
		
	$('#email_address_for_online_submissions').removeAttr('disabled');
	$('#email_address_for_online_submissions').addClass('required email');
	$('#email_address_for_online_submissions').focus();

    return false;
});

$('#save_{{question_id}}').click(function(event) {
	$target = $(event.target);
	
	if ($('#accepts_electronic_submissions_yes_with_exception').is(':checked')) 
	{
		if ($('#radio_url_for_online_submissions').is(':checked')) 
		{
			$('#email_address_for_online_submissions').removeClass('required');
		}
		else
		{
			if ($('#radio_email_address_for_online_submissions').is(':checked')) 
			{
				$('#url_for_online_submissions').removeClass('required');
			}
		}
	}
	
	if ($('#form_{{question_id}}').validate().form()) {
		$('save_{{question_id}}').attr('disabled','disabled');
		$('#qa_{{question_id}}_add').hide('slow');
		controller.submitForm('#form_{{question_id}}');
	}	
	
	return false;
});

$('#save_edit_{{answer_id}}').click(function(event) {
	$target = $(event.target);
	//alert('edit');
	if ($('#accepts_electronic_submissions_yes_with_exception').is(':checked')) 
	{	//alert('1');
		if ($('#radio_url_for_online_submissions').is(':checked')) 
		{	//alert('2');
			$('#email_address_for_online_submissions').removeClass('required');
		}
		else
		{	//alert('3');
			if ($('#radio_email_address_for_online_submissions').is(':checked')) 
			{	//alert('4');
				$('#url_for_online_submissions').removeClass('required');
			}
		}
	}
	
	if ($('#form_edit_{{answer_id}}').validate().form()) {
		$('save_edit_{{answer_id}}').attr('disabled','disabled');
		$('#qa_{{answer_id}}_add').hide('slow');
		controller.submitForm('#form_edit_{{answer_id}}');
	}	
	
	return false;
});