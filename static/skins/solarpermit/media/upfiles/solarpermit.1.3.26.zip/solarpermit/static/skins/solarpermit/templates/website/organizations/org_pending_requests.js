$('#org_members_list1').jscroll({
	callback: function () {
		//since the list changed, bind events only to items with unbind class (new)
		
	}
});